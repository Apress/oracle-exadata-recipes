REM Name: 	lst11-01-asm-repairtime.sql
REM Purpose: 	Adjusts disk_repair_time for an ASM disk group
REM Usage: 	From ASM Instance as SYSASM, SQL> @lst11-01-asm-repairtime.sql
REM 	 : 	Enter an ASM disk group name 

set echo on
alter diskgroup &&diskgroup_name set attribute 'disk_repair_time'='&&disk_repair_time';
undefine diskgroup_name
undefine disk_repair_time
