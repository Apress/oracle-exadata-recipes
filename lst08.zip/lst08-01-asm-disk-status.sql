REM Name: 	lst08-01-asm-disk-status.sql
REM Purpose: 	Display ASM disk group and disk status
REM Usage: 	From ASM Instance as SYSASM, SQL> @lst08-01-asm-disk-status.sql
REM 	 : 	Enter an ASM failgroup name and disk path

set lines 150
set pages 80
col path format a50
col name format a10 head 'Disk Group'
col path format a45 head 'Disk'
col mode_status format a12 head 'Disk Status'
col state format a10 head 'State'
col failgroup format a20 head 'Failgroup'
set echo on
select a.name,b.path,b.state,b.mode_status,b.failgroup
from v$asm_diskgroup a, v$asm_disk b
where a.group_number=b.group_number
and (b.failgroup='&&failgroup_name' or '&&failgroup_name' is null)
and b.path like '%'||'&&disk_path'||'%'
order by 2,1
/
undefine failgroup_name
undefine disk_path
