REM Name: 	lst08-02-failgroup-status.sql
REM Purpose: 	Display ASM disk status for disks in a FG
REM Usage: 	From ASM Instance as SYSASM, SQL> @lst08-02-failgroup-status.sql
REM 	 : 	Enter an ASM failgroup name 

set lines 150
set pages 80
col path format a50
col name format a10 head 'Disk Group'
col path format a45 head 'Disk'
col mode_status format a12 head 'Disk Status'
col state format a10 head 'State'
col failgroup format a20 head 'Failgroup'
set echo on
select a.name,b.path,b.state,b.mode_status,b.failgroup
from v$asm_diskgroup a, v$asm_disk b
where a.group_number=b.group_number
and (b.failgroup='&&failgroup_name' or '&&failgroup_name' is null)
order by 2,1
/
undefine failgroup_name
