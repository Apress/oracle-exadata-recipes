REM Name: 	lst21-11-parallel-limit.sql
REM Purpose:    Shows parallel degree limit calculations
REM Usage: 	From DB login as SYSDBA and do:
REM		SQL> @lst21-11-parallel-limit.sql

col parallel_limit format 999 head 'Parallel Degree Limit'
set echo on
select decode(p1.value,'CPU',
	p2.value*p3.value*p4.value,
	p1.value) parallel_limit
from v$parameter p1, v$parameter p2,
     v$parameter p3, v$parameter p4
where p1.name='parallel_degree_limit'
and p2.name='cpu_count'
and p3.name='parallel_threads_per_cpu'
and p4.name='parallel_server_instances'
/
