REM Name: 	9lst21-01-dbfsspace.sql
REM Purpose:  	Displays free space for DBFS_DG ASM disk group
REM Usage: 	From DB or ASM  Instance, SQL> @lst21-01-dbfsspace.sql

col type format a15 head 'File Type'
col asm_dg format a32 head 'ASM Diskgroup path'
col cnt format 9999 head 'Number of files'
set lines 80
set echo on
select name,total_mb,free_mb
from v$asm_diskgroup
where name='DBFS_DG'
/
