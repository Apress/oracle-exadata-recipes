REM Name: 	lst21-14-autodop-impx-comp.sql
REM Purpose:    Reports SQL from AWR where In-Memory PX was utilized
REM Usage: 	From DB login as SYSDBA and do:
REM		SQL> @lst21-14-autodop-impx-comp.sql

set lines  200
col sql_id format a15 head 'SQL ID'
col px_servers format 999 head 'PX Servers|Per Exec'
col elps format 999999999.90 head 'Elps Sec|Per Exec'
col st format a60 head 'SQL'
col offloadelig format a12  head 'Offloaded'
col execs format 999 head 'Execs'
col impx format a12  head 'In-Memory|PX'
col offloadbytes format 999999999.90 head 'IO Offload|MB'
set lines 200
set echo on
select  ss.sql_id,
	sum(ss.executions_total) execs,
	sum(ss.PX_SERVERS_EXECS_total)/sum(ss.executions_total) px_servers,
	decode(sum(ss.io_offload_elig_bytes_total),0,'No','Yes') offloadelig,
	decode(sum(ss.io_offload_elig_bytes_total),0,'Yes','No') impx,
	sum(ss.io_offload_elig_bytes_total)/1024/1024 offloadbytes,
	sum(ss.elapsed_time_total)/1000000/sum(ss.executions_total)/sum(ss.px_servers_execs_total) elps,
	dbms_lob.substr(st.sql_text,60,1) st
from dba_hist_sqlstat ss, dba_hist_sqltext st
where ss.px_servers_execs_total > 0
and ss.sql_id=st.sql_id
and upper(st.sql_text) like '%IN-MEM PX%'
group by ss.sql_id,dbms_lob.substr(st.sql_text,60,1)
order by 5
/
