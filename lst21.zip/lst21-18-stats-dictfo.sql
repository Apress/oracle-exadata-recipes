REM Name: 	lst21-18-stats-dictfo.sql
REM Purpose:    Gather data dictionary and fixed object statistics
REM Usage: 	From DB login as SYSDBA and do:
REM		SQL> @lst21-18-stats-dictfo.sql

set echo on
exec dbms_stats.gather_dictionary_stats;
exec dbms_stats.gather_fixed_objects_stats;
