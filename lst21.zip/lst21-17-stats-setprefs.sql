REM Name: 	lst21-16-stats-parms.sql
REM Purpose:    Reports optimizer stats prefss
REM Usage: 	From DB login as SYSDBA and do:
REM		SQL> @lst21-16-stats-parms.sql

col prefs format a30 head 'Parameter'
set lines 200
set pages 0
set echo on
exec dbms_stats.set_database_prefs(pname=>'CASCADE',pvalue=>'DBMS_STATS.AUTO_CASCADE');
exec dbms_stats.set_database_prefs(pname=>'DEGREE',pvalue=>'DBMS_STATS.AUTO_DEGREE');
exec dbms_stats.set_database_prefs(pname=>'ESTIMATE_PERCENT',pvalue=>'DBMS_STATS.AUTO_SAMPLE_SIZE');
exec dbms_stats.set_database_prefs(pname=>'GRANULARITY',pvalue=>'AUTO');
exec dbms_stats.set_database_prefs(pname=>'METHOD_OPT',pvalue=>'FOR ALL COLUMNS SIZE AUTO');
exec dbms_stats.set_database_prefs(pname=>'STALE_PERCENT',pvalue=>'10');
exec dbms_stats.set_database_prefs(pname=>'NO_INVALIDATE',pvalue=>'DBMS_STATS.AUTO_INVALIDATE');
exec dbms_stats.set_database_prefs(pname=>'PUBLISH',pvalue=>'TRUE');
exec dbms_stats.set_database_prefs(pname=>'INCREMENTAL',pvalue=>'TRUE');
