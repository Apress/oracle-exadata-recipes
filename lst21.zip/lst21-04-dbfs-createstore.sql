REM Name: 	lst21-04-dbfs-createstore.sql
REM Purpose:  	Create DBFS store
REM Usage: 	From DB login as DBFS and do:
REM		 SQL> @lst21-04-dbfs-createstore.sql

set echo on
conn dbfs/dbfs
@$ORACLE_HOME/rdbms/admin/dbfs_create_filesystem.sql DBFS_TBS DATA_DBFS 
