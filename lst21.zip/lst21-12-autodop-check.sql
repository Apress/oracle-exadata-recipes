REM Name: 	lst21-12-autodop-check.sql
REM Purpose:    Shows status of Auto DOP config
REM Usage: 	From DB login as SYSDBA and do:
REM		SQL> @lst21-12-autodop-check.sql
set lines 120
col name format a45 head 'Parameter'
col value format a20 head 'Value'
col descr format a45 head 'Notes'
set echo on
select name,value,decode(value,'AUTO','Auto DOP is enabled',
			'LIMITED','Auto DOP is implemented in limited fashion',
		'MANUAL','Auto DOP is not implemented') descr
from v$parameter
where name='parallel_degree_policy'
/

select  a.ksppinm name, b.ksppstvl value
from x$ksppi a, x$ksppsv b
where a.indx = b.indx
and a.ksppinm in ('_parallel_cluster_cache_pct','_parallel_cluster_cache_policy','_parallel_statement_queuing')
order by 1,2
/
