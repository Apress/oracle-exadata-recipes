REM Name: 	lst21-07-io-calibrate.sql
REM Purpose:  	Seeds IO calibration statistics
REM Usage: 	From DB login as SYSDBA and do:
REM		 SQL> @lst21-07-io-calibrate.sql

set echo on

delete from resource_io_calibrate$;
insert into resource_io_calibrate$
values(current_timestamp, current_timestamp, 0, 0, 200, 0, 0);
commit;
