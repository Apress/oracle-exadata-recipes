REM Name: 	lst21-03-dbfs-creatuser.sql
REM Purpose:  	Create DBFS user
REM Usage: 	From DB, SQL> @lst21-03-dbfs-creatuser.sql

set lines 80
set echo on
create user dbfs identified by dbfs
quota unlimited on dbfs_tbs
/

grant create session, create table, create procedure,
dbfs_role to dbfs
/

