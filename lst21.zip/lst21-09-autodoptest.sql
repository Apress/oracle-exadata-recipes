REM Name: 	lst21-09-autodoptest.sql
REM Purpose:    Runs a full scan for Auto DOP tests
REM		SQL> @lst21-09-autodoptest.sql

set serveroutput on size 20000
variable n number
exec :n := dbms_utility.get_time;
spool autodop_&1..lst
select /* queue test 0 */ count(*) from DWB_RTL_SLS_RETRN_LINE_ITEM;
begin
   dbms_output.put_line
   ( (round((dbms_utility.get_time - :n)/100,2)) || ' seconds' );
end;
/
spool off
exit
