REM Name: 	lst21-06-dbfs-dir-perm.sql
REM Purpose:  	Create DBA_DIRECTORIES directory on DBFS file system and set permissions and quotas
REM Usage: 	From DB login as SYSDBA and do:
REM		 SQL> @lst21-06-dbfs-dir-perm.sql

set echo on
conn / as sysdba
create directory dbfs_dir
as '/data_dbfs/DATA_DBFS'
/
grant all on directory dbfs_dir to apps
/
alter user apps quota unlimited on dbfs_tbs
/
