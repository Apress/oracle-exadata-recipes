REM Name: 	lst21-15-stats-autotask.sql
REM Purpose:    Reports optimizer auto task details
REM Usage: 	From DB login as SYSDBA and do:
REM		SQL> @lst21-15-stats-autotask.sql
set lines 200
col client_name format a35 head 'AutoTask Client'
col status format a10 head 'Status'
col window_group format a20 head 'Window Group'
col window_name format a17 head 'Window'
col task_name format a25 head 'Task Name'
col program_action format a42 head 'Program'
col next_start_date format a20  head 'Next Start'
set echo on
select ac.client_name,ac.status,
       at.task_name,
       sp.program_action
from dba_autotask_client ac,
     dba_autotask_task at,
     dba_scheduler_programs sp
where ac.client_name='auto optimizer stats collection'
and ac.client_name=at.client_name
and upper(at.task_name)=upper(sp.program_name)
/

select ac.client_name,ac.window_group,wm.window_name,
       to_char(win.next_start_date,'DD-MON-RR HH24:MI:SS') next_start_date
from dba_autotask_client ac,
     dba_scheduler_wingroup_members wm,
     dba_scheduler_windows win
where ac.client_name='auto optimizer stats collection'
and ac.window_group=wm.window_group_name
and wm.window_name=win.window_name
/
