REM Name: 	lst21-08-io-calibrate-drm.sql
REM Purpose:  	Seeds IO calibration statistics
REM Usage: 	From DB login as SYSDBA and do:
REM		 SQL> @lst21-08-io-calibrate-drm.sql

set echo on
set serveroutput on
declare
 lat  integer;
 iops integer;
 mbps integer;
begin
 dbms_resource_manager.calibrate_io(&&num_disks,10,iops,mbps,lat);
 dbms_output.put_line('Max IOPs = '||iops);
 dbms_output.put_line('Latency  = '||lat);
 dbms_output.put_line('Max MBPS = '||iops);
end;
/
