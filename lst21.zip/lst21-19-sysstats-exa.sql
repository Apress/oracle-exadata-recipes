REM Name: 	lst21-19-sysstats-exa.sql
REM Purpose:    Gather system statistics for Exadata
REM Usage: 	From DB login as SYSDBA and do:
REM		SQL> @lst21-19-sysstats-exa.sql

set echo on
exec dbms_stats.gather_system_stats('EXADATA');
