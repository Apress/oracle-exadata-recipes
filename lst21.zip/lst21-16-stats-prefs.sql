REM Name: 	lst21-16-stats-parms.sql
REM Purpose:    Reports optimizer stats prefss
REM Usage: 	From DB login as SYSDBA and do:
REM		SQL> @lst21-16-stats-parms.sql

col prefs format a30 head 'Parameter'
set lines 200
set pages 0
set echo on
select dbms_stats.get_prefs('CASCADE') prefs from dual;
select dbms_stats.get_prefs('DEGREE') prefs from dual;
select dbms_stats.get_prefs('ESTIMATE_PERCENT') prefs from dual;
select dbms_stats.get_prefs('METHOD_OPT') prefs from dual;
select dbms_stats.get_prefs('NO_INVALIDATE') prefs from dual;
select dbms_stats.get_prefs('GRANULARITY') prefs from dual;
select dbms_stats.get_prefs('PUBLISH') prefs from dual;
select dbms_stats.get_prefs('INCREMENTAL') prefs from dual;
select dbms_stats.get_prefs('STALE_PERCENT') prefs from dual;
