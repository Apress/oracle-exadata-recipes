REM Name: 	lst21-02-dbfs-createtbs.sql
REM Purpose:  	Create DBFS tablepsace
REM Usage: 	From DB, SQL> @lst21-02-dbfs-createtbs.sql

set lines 80
set echo on
create bigfile tablespace dbfs_tbs
datafile '+DBFS_DG' size 100g
/

