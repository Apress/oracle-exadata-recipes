REM Name: 	lst21-05-dbfs-createstore-adv.sql
REM Purpose:  	Create DBFS store
REM Usage: 	From DB login as DBFS and do:
REM		 SQL> @lst21-05-dbfs-createstore-adv.sql

set echo on
conn dbfs/dbfs
@$ORACLE_HOME/rdbms/admin/dbfs_create_filesystem_advanced.sql DBFS_TBS DATA_DBFS nocompress nodeduplicate noencrypt non-partition
