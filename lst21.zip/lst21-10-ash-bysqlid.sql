REM Name: 	lst21-10-ash-bysqlid.sql
REM Purpose:    Reports ASH time breakdown per sql_id	
REM Usage: 	From DB login as SYSDBA and do:
REM		SQL> @lst21-10-ash-bysqlid.sql

col sql_id format a15 head 'sql_id'
col evt format a30 head 'CPU or Event'
col dbt format 9999999.90 head 'Time (sec)'
set echo on

select sql_id,evt,count(*) dbt from 
(select sql_id,sample_id,sample_time,session_state,
decode(session_state,'ON CPU','CPU + CPU Wait',event) evt
from gv$active_session_history
where sql_id = '&&sql_id'
and sample_time > sysdate-&&mins_ago/1440)
group by sql_id,evt
order by 3 desc
/
undefine sql_id
undefine mins_ago
