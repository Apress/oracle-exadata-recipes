REM Name: 	lst05-17-db-growth.sql
REM Purpose:  	Calculates growth rate of database
REM Usage: 	From DB Instance, SQL> @lst05-17-db-growth.sql
col 	initalloc 	format 99999990.90 head 'Start |Alloc (GB)'
col 	initused 	format 99999990.90 head 'Start |Used (GB)'
col 	curralloc 	format 99999990.90 head 'Curr |Alloc (GB)'
col 	currused 	format 99999990.90 head 'Curr |Used (GB)'
col 	pctused 	format 999.99 head '% Used'
col 	alloc_gbpd	format 99999.99 head 'Alloc Growth|GB/day'
col tbs format a20 head 'Tablespace'
col 	used_gbpd	format 99999.99 head 'Used Growth|GB/day'
set lines 180
set pages 80
set trimspool on
break on report
compute sum of initalloc initused curralloc currused alloc_gbpd used_gbpd on report
set echo on
SELECT tbs tbs, ROUND (init_alloc_gb, 2) initalloc,
       ROUND (init_used_gb, 2) initused, ROUND (curr_alloc_gb, 2) curralloc,
       ROUND (curr_used_gb, 2) currused,
       ROUND (100 * (curr_used_gb / curr_alloc_gb), 2) PCTUSED,
       ROUND (alloc_gbperday, 2) alloc_gbpd,
       ROUND (used_gbperday, 2) used_gbpd
  FROM (SELECT tsmin.tsname tbs, tsmin.tablespace_size init_alloc_gb,
               tsmin.tablespace_usedsize init_used_gb,
               tsmax.tablespace_size curr_alloc_gb,
               tsmax.tablespace_usedsize curr_used_gb,
                 (tsmax.tablespace_size - tsmin.tablespace_size) / (tsmax.snaptime - tsmin.snaptime) alloc_gbperday,
                 (tsmax.tablespace_usedsize - tsmin.tablespace_usedsize)
               / (tsmax.snaptime - tsmin.snaptime) used_gbperday          
        FROM   (SELECT *
                  FROM (SELECT TRUNC (s.begin_interval_time) snaptime,
                               t.tsname, (ts.BLOCKSIZE * u.tablespace_size) / 1024 / 1024 / 1024 tablespace_size,
                                 (ts.BLOCKSIZE * u.tablespace_usedsize) / 1024 / 1024 / 1024 tablespace_usedsize,
                               (RANK () OVER (PARTITION BY t.tsname ORDER BY s.snap_id ASC)
                               ) latest,
                               s.end_interval_time endtime
                          FROM dba_hist_snapshot s,
                               v$instance i, v$database d,
                               dba_hist_tablespace_stat t,
                               dba_hist_tbspc_space_usage u,
                               SYS.ts$ ts
                         WHERE s.snap_id = t.snap_id
			   AND s.dbid=d.dbid
			   AND s.dbid=t.dbid
			   AND s.dbid=u.dbid
                           AND i.instance_number = s.instance_number
                           AND s.instance_number = t.instance_number
                           AND ts.ts# = t.ts#
                           AND t.snap_id = u.snap_id
                           AND t.ts# = u.tablespace_id)
                 WHERE latest = 1) tsmin,
               (SELECT *
                  FROM (SELECT TRUNC (s.begin_interval_time) snaptime,
                               t.tsname,
                                 (ts.BLOCKSIZE * u.tablespace_size) / 1024 / 1024 / 1024 tablespace_size,
                                 (ts.BLOCKSIZE * u.tablespace_usedsize) / 1024 / 1024 / 1024 tablespace_usedsize,
                               (RANK () OVER (PARTITION BY t.tsname ORDER BY s.snap_id DESC)
                               ) latest,
                               s.end_interval_time endtime
                          FROM dba_hist_snapshot s,
                               v$instance i,v$database d,
                               dba_hist_tablespace_stat t,
                               dba_hist_tbspc_space_usage u,
                               SYS.ts$ ts
                         WHERE s.snap_id = t.snap_id
			   AND s.dbid=d.dbid
			   AND s.dbid=t.dbid
			   AND s.dbid=u.dbid
                           AND i.instance_number = s.instance_number
                           AND s.instance_number = t.instance_number
                           AND t.snap_id = u.snap_id
                           AND ts.ts# = t.ts#
                           AND t.ts# = u.tablespace_id)
                 WHERE latest = 1) tsmax
  WHERE tsmin.tsname = tsmax.tsname and tsmax.snaptime > tsmin.snaptime)
/
