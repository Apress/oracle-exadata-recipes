REM Name: 	lst05-06-awr-cpu-corecnt-forexa.sql
REM Purpose: 	Determine Exadata Config per AWR CPU Load
REM Usage: 	From DB Instance, SQL> @lst05-06-awr-cpu-corecnt-forexa.sql
REM 		Enter num_addtl_dbs, pct_resource_load, margin_err, and core_multiplier

set arraysize 5000
set termout on
set echo off verify off
set lines 290
set pages 180
col MaxOraCPU 	format 990.00 		head 'Max Non-IO|CPU Req'
col MaxOraIOCPU	format 990.00 		head 'Max IO|CPU Req'
col MaxOraCPUTot	format 990.00		head 'Max Total CPU|Req'
col exa_for_compute 	format a30 	head 'Exadata Recommendaton|Compute Grid'
col exa_for_storage 	format a30 	head 'Exadata Recommendaton|Storage Grid'

set colsep "|"
set echo on
select  max(OraCPU) MaxOraCPU, 
	max(OraIOCPU) MaxOraIOCPU,
	(case
	  when max(OraCPU) < (.65*48) then 'Quarter Rack'
	  when max(OraCPU) between (.65*48) and (.65*96) then 'Half Rack'
	  when max(OraCPU) between (.65*96) and (.65*192) then 'Full Rack'
	  else 'Full Rack +'
	end) exa_for_compute,
	(case
	  when max(OraIOCPU) < 72 then 'Quarter Rack'
	  when max(OraIOCPU) between 72 and 168 then 'Half Rack'
	  when max(OraIOCPU) between 168 and 336 then 'Full Rack'
	  else 'Full Rack +'
	end) exa_for_storage
 from (
select 
	(OraCPU + (&&num_addtl_dbs * &&pct_resource_load * &&margin_err * OraCPU)) 
		* &&core_multiplier OraCPU,
	(OraIOCPU + (&&num_addtl_dbs * &&pct_resource_load * &&margin_err * OraIOCPU)) 
		* &&core_multiplier OraIOCPU
  from (
select id,tm,dur,CPUs,
        aas, 
	oracpupct,
        (case
          when (greatest(0,aas - (oracpupct * CPUs))) > 0 then
               ((oracpupct * CPUs) + (.5 * (aas - (oracpupct * CPUs))))
          else (oracpupct * CPUs)
        end) OraCPU,
        greatest(0,aas - (oracpupct * CPUs)) OraIOCPU,
        (( oracpupct * CPUs) + greatest(0,aas - (oracpupct * CPUs))) OraCPUTot
from (
select  snaps.id, snaps.tm,snaps.dur,
        osstat.num_cpus CPUs,
        (((timemodel.dbt -
                lag(timemodel.dbt,1) over (order by snaps.id)))/1000000)/dur/60 aas ,
        (((((timemodel.dbc -
                lag(timemodel.dbc,1) over (order by snaps.id)))/1000000) +
          (((timemodel.bgc -
                lag(timemodel.bgc,1) over (order by snaps.id)))/1000000)) /
                (osstat.num_cpus * 60 * dur)) oracpupct,
        greatest((((timemodel.dbt -
                lag(timemodel.dbt,1) over (order by snaps.id)))/1000000)/dur/60,
        osstat.num_cpus * ((((((timemodel.dbc
                - lag(timemodel.dbc,1) over (order by snaps.id)))/1000000) +
          (((timemodel.bgc - lag(timemodel.bgc,1) over (order by snaps.id)))/1000000)) /
                (osstat.num_cpus * 60 * dur)))) cpuneed
 from
 ( /* DBA_HIST_SNAPSHOT */
 select distinct id,dbid,tm,instances,max(dur) over (partition by id) dur from (
 select distinct s.snap_id id, s.dbid,
    to_char(s.end_interval_time,'DD-MON-RR HH24:MI') tm,
    count(s.instance_number) over (partition by snap_id) instances,
    1440*((cast(s.end_interval_time as date)
                - lag(cast(s.end_interval_time as date),1) over (order by s.snap_id))) dur
                 from   dba_hist_snapshot s,
    v$database d
 where s.dbid=d.dbid)
 ) snaps,
 ( /* Data from DBA_HIST_OSSTAT */
  select  *
        from
        (select snap_id,dbid,stat_name,value from
        dba_hist_osstat
  ) pivot
  (sum(value) for (stat_name)
        in ('NUM_CPUS' as num_cpus,'BUSY_TIME' as busy_time,
            'LOAD' as load,'USER_TIME' as user_time,
                'SYS_TIME' as sys_time, 'IOWAIT_TIME' as iowait_time))
  ) osstat,
  ( /* DBA_HIST_TIME_MODEL */
   select * from
        (select snap_id,dbid,stat_name,value from
        dba_hist_sys_time_model
   ) pivot
   (sum(value) for (stat_name)
        in ('DB time' as dbt, 'DB CPU' as dbc, 'background cpu time' as bgc,
             'RMAN cpu time (backup/restore)' as rmanc))
  ) timemodel
where dur > 0
and snaps.id=osstat.snap_id
and snaps.dbid=osstat.dbid
and snaps.id=timemodel.snap_id
and snaps.dbid=timemodel.dbid)
order by id asc
) where OraCPUTot < 100
)
/
undefine num_addtl_dbs
undefine pct_resource_load
undefine margin_err
undefine core_multiplier
