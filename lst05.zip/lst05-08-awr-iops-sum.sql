REM Name: 	lst05-08-awr-iops-sum.sql
REM Purpose: 	Retrieve Summarized IOPs-related metrics from AWR
REM Usage: 	From DB Instance, SQL> @lst05-08-awr-iops-sum.sql

set arraysize 5000
set termout on
set echo off verify off
set lines 290
set pages 900
col id format 99999 head 'Snap|ID'
col tm format a15 head 'Snap|Start'
col instances format 999 head 'RAC|Nodes'
col dur format 999.99 head 'Duration|Mins'
col AvgIOPsr 	format 999990.00 	head 'Avg IOPs|Reads'
col AvgIOPsw 	format 999990.00 	head 'Avg IOPs|Write'
col AvgIOPsredo format 999990.00 	head 'Avg IOPs|Redo'
col AvgTotiops 	format 999990.00 	head 'Avg IOPs|Total'
col MaxIOPsr 	format 999990.00 	head 'Max IOPs|Reads'
col MaxIOPsw 	format 999990.00 	head 'Max IOPs|Write'
col MaxIOPsredo format 999990.00 	head 'Max IOPs|Redo'
col MaxTotiops 	format 999990.00 	head 'Max IOPs|Total'
set colsep "|"
set echo on
select 
	avg(IOPsr) AvgIOPsr, max(IOPsr) MaxIOPsr, 
	avg(IOPsw) AvgIOPsw, max(IOPsw) MaxIOPsw, 
	avg(IOPsr) AvgIOPsredo, max(IOPsredo) MaxIOPsredo,
	avg(Totiops) AvgTotiops, max(Totiops) MaxTotiops
from (
select  snaps.id, snaps.tm,snaps.dur,snaps.instances,
        ((sysstat.IOPsr - 
		lag (sysstat.IOPsr,1) over (order by snaps.id)))/dur/60  IOPsr,
        ((sysstat.IOPsw - 
		lag (sysstat.IOPsw,1) over (order by snaps.id)))/dur/60  IOPsw,
        ((sysstat.IOPsredo - 
		lag (sysstat.IOPsredo,1) over (order by snaps.id)))/dur/60  IOPsredo,
        (((sysstat.IOPsr - 
		lag (sysstat.IOPsr,1) over (order by snaps.id)))/dur/60) + 
        (((sysstat.IOPsw - 
		lag (sysstat.IOPsw,1) over (order by snaps.id)))/dur/60) + 
        (((sysstat.IOPsredo - 
		lag (sysstat.IOPsredo,1) over (order by snaps.id)))/dur/60) Totiops,
        sysstat.logons_curr ,
        ((sysstat.logons_cum - 
		lag (sysstat.logons_cum,1) over (order by snaps.id)))/dur/60  logons_cum,
        ((sysstat.execs - 
		lag (sysstat.execs,1) over (order by snaps.id)))/dur/60 execs
 from
 ( /* DBA_HIST_SNAPSHOT */
 select distinct id,dbid,tm,instances,max(dur) over (partition by id) dur from (
 select distinct s.snap_id id, s.dbid,
    to_char(s.end_interval_time,'DD-MON-RR HH24:MI') tm,
    count(s.instance_number) over (partition by snap_id) instances,
    1440*((cast(s.end_interval_time as date) - lag(cast(s.end_interval_time as date),1) over (order by s.snap_id))) dur
 from   dba_hist_snapshot s,
    v$database d
 where s.dbid=d.dbid)
 ) snaps,
  ( /* DBA_HIST_SYSSTAT */
    select * from
        (select snap_id, dbid, stat_name, value from
        dba_hist_sysstat
    ) pivot
    (sum(value) for (stat_name) in
        ('logons current' as logons_curr, 'logons cumulative' as logons_cum, 'execute count' as execs,
	 'physical read IO requests' as IOPsr, 'physical write IO requests' as IOPsw,
	  'redo writes' as IOPsredo))
  ) sysstat
where dur > 0 
and snaps.id=sysstat.snap_id
and snaps.dbid=sysstat.dbid)
order by id asc
/
