REM Name: 	lst05-15-db-size.sql
REM Purpose:  	Retrieves database size, excluding archived redo logs
REM Usage: 	From DB Instance, SQL> @lst05-15-db-size.sql

col type format a15 head 'File Type'
col cnt format 9999 head 'Number of files'
col szgb format 99990.99 head 'Size (GB)'
set lines 80
set echo on
select 'Data Files' type,
	sum(bytes)/1024/1024/1024 szgb,
	count(*) cnt
from 	v$datafile
group by substr(name,1,instr(name,'/',1,2)-1)
union
select 'Temp Files',
	sum(bytes)/1024/1024/1024 szgb,
	count(*) cnt
from v$tempfile
group by substr(name,1,instr(name,'/',1,2)-1)
union
select 'Redo Member',
	sum(l.bytes)/1024/1024/1024 szgb,
	count(*) cnt
from v$logfile lf, v$log l
where l.group#=lf.group#
group by substr(member,1,instr(member,'/',1,2)-1)
/

