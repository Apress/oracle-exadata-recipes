REM Name: 	lst05-20-db-growth-forexa.sql
REM Purpose:  	Sizes Exadata config based on growth rates
REM Usage: 	From DB Instance, SQL> @lst05-20-db-growth-forexa.sql
REM		hp_or_hc: HP for High Perf, HC for High Cap
REM		pct_for_data = fractional % of usable storage to use for "data"
REM		asm_redundancy = NORMAL or HIGH
REM 		num_dbs = Number of databases
REM		pct_of_db = Percentage (decimal) of DB size for other &num_dbs (1 = 100%, .25 = 25%, etc)

col 	curralloc 	format 99999990.90 head 'Curr |Alloc (GB)'
col 	grate 		format 99999.99 head 'Growth Rate|GB/day'
col 	year1		format 99999990.90 head '1-year|Size (GB)'
col 	year2		format 99999990.90 head '2-year|Size (GB)'
col 	year3		format 99999990.90 head '3-year|Size (GB)'
col 	year5		format 99999990.90 head '5-year|Size (GB)'
col 	drivetype	format a30 head 'Drive Type'
col 	asmredund	format a30 head 'ASM Redundancy'
col 	exa_model	format a35 head 'Exadata Config Recommendation'

set lines 180
set pages 80
set trimspool on
set echo on
select curralloc,grate,year5,
     decode(upper('&&hp_or_hc'),'HP','High Performance','HC','High Capacity','High Performance') drivetype,	
     decode(upper('&&asm_redundancy'),'NORMAL','Normal','HIGH','High','Normal') asmredund,	
     case
	when upper('&&hp_or_hc') = 'HP' then
	  case 
		when upper('&&asm_redundancy') = 'NORMAL' then
		  case
			when year5 < (10547*&&pct_for_data) then 'Quarter Rack'
			when year5 between (10547*&&pct_for_data) and (25804*&&pct_for_data) then 'Half Rack'
			when year5 between (25804*&&pct_for_data) and (51609*&&pct_for_data) then 'Full Rack'
			when year5 > (51609*&&pct_for_data) then 'Full Rack+'
	           end
		when upper('&&asm_redundancy') = 'HIGH'   then
		  case
			when year5 < (7372*&&pct_for_data) then 'Quarter Rack'
			when year5 between (7372*&&pct_for_data) and (17203*&&pct_for_data) then 'Half Rack'
			when year5 between (17203*&&pct_for_data) and (34406*&&pct_for_data) then 'Full Rack'
			when year5 > (34406*&&pct_for_data) then 'Full Rack+'
	           end
		else
		  case
			when year5 < (10547*&&pct_for_data) then 'Quarter Rack'
			when year5 between (10547*&&pct_for_data) and (25804*&&pct_for_data) then 'Half Rack'
			when year5 between (25804*&&pct_for_data) and (51609*&&pct_for_data) then 'Full Rack'
			when year5 > (51609*&&pct_for_data) then 'Full Rack+'
	           end
	  end
        when upper('&&hp_or_hc') = 'HC' then
	  case 
		when upper('&&asm_redundancy') = 'NORMAL' then
		  case
			when year5 < (55296*&&pct_for_data) then 'Quarter Rack'
			when year5 between (55296*&&pct_for_data) and (129024*&&pct_for_data) then 'Half Rack'
			when year5 between (129024*&&pct_for_data) and (258048*&&pct_for_data) then 'Full Rack'
			when year5 > (258048*&&pct_for_data) then 'Full Rack+'
	           end
		when upper('&&asm_redundancy') = 'HIGH'   then
		  case
			when year5 < (36864*&&pct_for_data) then 'Quarter Rack'
			when year5 between (36864*&&pct_for_data) and (86016*&&pct_for_data) then 'Half Rack'
			when year5 between (86016*&&pct_for_data) and (172032*&&pct_for_data) then 'Full Rack'
			when year5 > (172032*&&pct_for_data) then 'Full Rack+'
	           end
		else
		  case
			when year5 < (55296*&&pct_for_data) then 'Quarter Rack'
			when year5 between (55296*&&pct_for_data) and (129024*&&pct_for_data) then 'Half Rack'
			when year5 between (129024*&&pct_for_data) and (258048*&&pct_for_data) then 'Full Rack'
			when year5 > (258048*&&pct_for_data) then 'Full Rack+'
	           end
	  end
	else
	  case 
		when upper('&&asm_redundancy') = 'NORMAL' then
		  case
			when year5 < (10547*&&pct_for_data) then 'Quarter Rack'
			when year5 between (10547*&&pct_for_data) and (25804*&&pct_for_data) then 'Half Rack'
			when year5 between (25804*&&pct_for_data) and (51609*&&pct_for_data) then 'Full Rack'
			when year5 > (51609*&&pct_for_data) then 'Full Rack+'
	           end
		when upper('&&asm_redundancy') = 'HIGH'   then
		  case
			when year5 < (7372*&&pct_for_data) then 'Quarter Rack'
			when year5 between (7372*&&pct_for_data) and (17203*&&pct_for_data) then 'Half Rack'
			when year5 between (17203*&&pct_for_data) and (34406*&&pct_for_data) then 'Full Rack'
			when year5 > (34406*&&pct_for_data) then 'Full Rack+'
	           end
		else
		  case
			when year5 < (10547*&&pct_for_data) then 'Quarter Rack'
			when year5 between (10547*&&pct_for_data) and (25804*&&pct_for_data) then 'Half Rack'
			when year5 between (25804*&&pct_for_data) and (51609*&&pct_for_data) then 'Full Rack'
			when year5 > (51609*&&pct_for_data) then 'Full Rack+'
	           end
	  end
     end exa_model
from (
select curralloc, grate ,
       year1+(&&num_dbs * &&pct_db_size * year1) year1,
       year2+(&&num_dbs * &&pct_db_size * year2) year2,
       year3+(&&num_dbs * &&pct_db_size * year3) year3,
       year5+(&&num_dbs * &&pct_db_size * year5) year5
from (
 SELECT 
       ROUND (sum(curr_alloc_gb), 2) curralloc,
       greatest(sum(alloc_gbperday),sum(used_gbperday)) grate,
       (sum(curr_alloc_gb) + 
		365*(greatest(sum(alloc_gbperday),sum(used_gbperday))))
			-(sum(curr_alloc_gb)-sum(curr_used_gb)) year1,
       (sum(curr_alloc_gb) + 
		2*365*(greatest(sum(alloc_gbperday),sum(used_gbperday))))
			-(sum(curr_alloc_gb)-sum(curr_used_gb)) year2,
       (sum(curr_alloc_gb) + 
		3*365*(greatest(sum(alloc_gbperday),sum(used_gbperday))))
			-(sum(curr_alloc_gb)-sum(curr_used_gb)) year3,
       (sum(curr_alloc_gb) + 
		5*365*(greatest(sum(alloc_gbperday),sum(used_gbperday))))
			-(sum(curr_alloc_gb)-sum(curr_used_gb)) year5
  FROM (SELECT tsmin.tsname tbs, tsmin.tablespace_size init_alloc_gb,
               tsmin.tablespace_usedsize init_used_gb,
               tsmax.tablespace_size curr_alloc_gb,
               tsmax.tablespace_usedsize curr_used_gb,
                 (tsmax.tablespace_size - tsmin.tablespace_size) / (tsmax.snaptime - tsmin.snaptime) alloc_gbperday,
                 (tsmax.tablespace_usedsize - tsmin.tablespace_usedsize)
               / (tsmax.snaptime - tsmin.snaptime) used_gbperday          
        FROM   (SELECT *
                  FROM (SELECT TRUNC (s.begin_interval_time) snaptime,
                               t.tsname, (ts.BLOCKSIZE * u.tablespace_size) / 1024 / 1024 / 1024 tablespace_size,
                                 (ts.BLOCKSIZE * u.tablespace_usedsize) / 1024 / 1024 / 1024 tablespace_usedsize,
                               (RANK () OVER (PARTITION BY t.tsname ORDER BY s.snap_id ASC)
                               ) latest,
                               s.end_interval_time endtime
                          FROM dba_hist_snapshot s,
                               v$instance i, v$database d,
                               dba_hist_tablespace_stat t,
                               dba_hist_tbspc_space_usage u,
                               SYS.ts$ ts
                         WHERE s.snap_id = t.snap_id
			   AND s.dbid=d.dbid and s.dbid=t.dbid and s.dbid=u.dbid
                           AND i.instance_number = s.instance_number
                           AND s.instance_number = t.instance_number
                           AND ts.ts# = t.ts#
                           AND t.snap_id = u.snap_id
                           AND t.ts# = u.tablespace_id)
                 WHERE latest = 1) tsmin,
               (SELECT *
                  FROM (SELECT TRUNC (s.begin_interval_time) snaptime,
                               t.tsname,
                                 (ts.BLOCKSIZE * u.tablespace_size) / 1024 / 1024/  1024 tablespace_size,
                                 (ts.BLOCKSIZE * u.tablespace_usedsize) / 1024 / 1024 / 1024 tablespace_usedsize,
                               (RANK () OVER (PARTITION BY t.tsname ORDER BY s.snap_id DESC)
                               ) latest,
                               s.end_interval_time endtime
                          FROM dba_hist_snapshot s,
                               v$instance i, v$database d,
                               dba_hist_tablespace_stat t,
                               dba_hist_tbspc_space_usage u,
                               SYS.ts$ ts
                         WHERE s.snap_id = t.snap_id
			   AND s.dbid=d.dbid and s.dbid=t.dbid and s.dbid=u.dbid
                           AND i.instance_number = s.instance_number
                           AND s.instance_number = t.instance_number
                           AND t.snap_id = u.snap_id
                           AND ts.ts# = t.ts#
                           AND t.ts# = u.tablespace_id)
                 WHERE latest = 1) tsmax
  WHERE tsmin.tsname = tsmax.tsname and tsmax.snaptime > tsmin.snaptime)
))
/
undefine num_dbs
undefine pct_db_size
undefine hp_or_hc
undefine pct_for_data
undefine asm_redundancy
