REM Name	: lst05-05-awr-cpu-corecnt-sum-extr.sql
REM Purpose	: Summarized CPU capacity planning from AWR for Exadata
REM 		: With additional logic to amplify/extrapolate results 
REM Usage	: lst05-05-awr-cpu-corecnt-sum-extr.sql
REM      	: Enter num_addtl_dbs (additional databases)
REM 		: 	pct_resource_load (resource percentage compared to current DB )
REM 		: 	margin_err  (margin of error; 1.2 = 20% margin of error, 1 = no margin)


set arraysize 5000
set termout on
set echo off verify off
set lines 290
set pages 180
col id 		format 99999 head 'Snap|ID'
col tm 		format a15 head 'Snap|End'
col instances 	format 999 head 'RAC|Nodes'
col dur 	format 999.99 head 'Duration|Mins'
col CPUs 	format 999 head 'Current|CPUs'
col cap 	format 9999990.00 	head 'Tot CPU Time|Avail (s)'
col aas 	format 999.00 		head 'AAS'
col oracpupct   format 990.0 		head 'Ora|CPU%'
col AvgOraCPU 	format 990.00 		head 'Avg Non-IO|CPU Req'
col AvgOraIOCPU	format 990.00 		head 'Avg IO|CPU Req'
col AvgOraCPUTot	format 990.00		head 'Avg Total CPU|Req'
col MaxOraCPU 	format 990.00 		head 'Max Non-IO|CPU Req'
col MaxOraIOCPU	format 990.00 		head 'Max IO|CPU Req'
col MaxOraCPUTot	format 990.00		head 'Max Total CPU|Req'
col StdOraCPU 	format 990.00 		head 'StdDev Non-IO|CPU Req'
col StdOraIOCPU	format 990.00 		head 'StdDev IO|CPU Req'
col StdOraCPUTot	format 990.00		head 'StdDev Total CPU|Req'
set colsep "|"
set echo on
select  avg(OraCPU) AvgOraCPU, max(OraCPU) MaxOraCPU, stddev(OraCPU) StdOraCPU, 
	avg(OraIOCPU) AvgOraIOCPU, max(OraIOCPU) MaxOraIOCPU, stddev(OraIOCPU) StdOraIOCPU, 
	avg(OraCPUTot) AvgOraCPUTot, max(OraCPUTot) MaxOraCPUTot, stddev(OraCPUTot) StdOraCPUTot
 from (
select 
	(aas + (&&num_addtl_dbs * &&pct_resource_load * &&margin_err * aas )) aas,
	(oracpupct+ (&&num_addtl_dbs * &&pct_resource_load * &&margin_err * oracpupct)) oracpupct,
	(OraCPU + (&&num_addtl_dbs * &&pct_resource_load * &&margin_err * OraCPU)) OraCPU,
	(OraIOCPU + (&&num_addtl_dbs * &&pct_resource_load * &&margin_err * OraIOCPU)) OraIOCPU,
	(OraCPUTot + (&&num_addtl_dbs * &&pct_resource_load * &&margin_err * OraCPUTot)) OraCPUTot
  from (
select id,tm,dur,CPUs,
        aas, 
	oracpupct,
        (case
          when (greatest(0,aas - (oracpupct * CPUs))) > 0 then
               ((oracpupct * CPUs) + (.5 * (aas - (oracpupct * CPUs))))
          else (oracpupct * CPUs)
        end) OraCPU,
        greatest(0,aas - (oracpupct * CPUs)) OraIOCPU,
        (( oracpupct * CPUs) + greatest(0,aas - (oracpupct * CPUs))) OraCPUTot
from (
select  snaps.id, snaps.tm,snaps.dur,
        osstat.num_cpus CPUs,
        (((timemodel.dbt -
                lag(timemodel.dbt,1,0) over (order by snaps.id)))/1000000)/dur/60 aas ,
        (((((timemodel.dbc -
                lag(timemodel.dbc,1,0) over (order by snaps.id)))/1000000) +
          (((timemodel.bgc -
                lag(timemodel.bgc,1,0) over (order by snaps.id)))/1000000)) /
                (osstat.num_cpus * 60 * dur)) oracpupct,
        greatest((((timemodel.dbt -
                lag(timemodel.dbt,1,0) over (order by snaps.id)))/1000000)/dur/60,
        osstat.num_cpus * ((((((timemodel.dbc
                - lag(timemodel.dbc,1,0) over (order by snaps.id)))/1000000) +
          (((timemodel.bgc - lag(timemodel.bgc,1,0) over (order by snaps.id)))/1000000)) /
                (osstat.num_cpus * 60 * dur)))) cpuneed
 from
 ( /* DBA_HIST_SNAPSHOT */
 select distinct id,dbid,tm,instances,max(dur) over (partition by id) dur from (
 select distinct s.snap_id id, s.dbid,
    to_char(s.end_interval_time,'DD-MON-RR HH24:MI') tm,
    count(s.instance_number) over (partition by snap_id) instances,
    1440*((cast(s.end_interval_time as date)
                - lag(cast(s.end_interval_time as date),1) over (order by s.snap_id))) dur
                 from   dba_hist_snapshot s,
    v$database d
 where s.dbid=d.dbid)
 ) snaps,
 ( /* Data from DBA_HIST_OSSTAT */
  select  *
        from
        (select snap_id,dbid,stat_name,value from
        dba_hist_osstat
  ) pivot
  (sum(value) for (stat_name)
        in ('NUM_CPUS' as num_cpus,'BUSY_TIME' as busy_time,
            'LOAD' as load,'USER_TIME' as user_time,
                'SYS_TIME' as sys_time, 'IOWAIT_TIME' as iowait_time))
  ) osstat,
  ( /* DBA_HIST_TIME_MODEL */
   select * from
        (select snap_id,dbid,stat_name,value from
        dba_hist_sys_time_model
   ) pivot
   (sum(value) for (stat_name)
        in ('DB time' as dbt, 'DB CPU' as dbc, 'background cpu time' as bgc,
             'RMAN cpu time (backup/restore)' as rmanc))
  ) timemodel
where dur > 0
and snaps.id=osstat.snap_id
and snaps.dbid=osstat.dbid
and snaps.id=timemodel.snap_id
and snaps.dbid=timemodel.dbid)
order by id asc
) where OraCPUTot < 100
)
/
undefine num_addtl_dbs
undefine pct_resource_load
undefine margin_err
