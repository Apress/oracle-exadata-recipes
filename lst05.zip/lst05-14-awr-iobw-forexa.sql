REM Name: 	lst05-14-awr-iobw-forexa.sql
REM Purpose: 	Retrieve Summarized IO Bandwidth related metrics from AWR 
REM 		Report Exadata configuration
REM 	  : 	With extrapolations for number of instances, etc
REM Usage: 	From DB Instance, SQL> @lst05-14-awr-iobw-forexa.sql


set arraysize 5000
set termout on
set echo off verify off
set lines 290
set pages 900
col id format 99999 head 'Snap|ID'
col tm format a15 head 'Snap|Start'
col instances format 999 head 'RAC|Nodes'
col dur format 999.99 head 'Duration|Mins'
col MaxIOmbpsr 	format 999990.00 	head 'Max MBPS|Reads'
col MaxIOmbpsw 	format 999990.00 	head 'Max MBPS|Write'
col MaxIOmbpsredo 	format 999990.00 	head 'Max MBPS|Redo'
col MaxTotmbps 	format 999990.00 	head 'Max MBPS|Total'
col exa_hp      format a30              head 'Exadata Recommendaton|HP Disks'
col exa_hc      format a30              head 'Exadata Recommendaton|HC Disks'
set colsep "|"
set echo on
select  max(IOmbpsr) MaxIOMbpsr,
	max(IOmbpsw) MaxIOMbpsw,
	max(IOmbpsredo) MaxIOMbpsredo,
	max(Totmbps) MaxTotmbps,
	(case
	 	when max(Totmbps)/1024 < 4.8 then 'Quarter Rack'
		when max(Totmbps)/1024 between 4.8 and 11.2 then 'Half Rack'
		when max(Totmbps)/1024 between 11.2 and 22.4 then 'Full Rack'
		when max(Totmbps)/1024 > 22.4 then 'Full Rack+'
	end) exa_hp,
	(case
	 	when max(Totmbps)/1024 < 3.9 then 'Quarter Rack'
		when max(Totmbps)/1024 between 3.9 and 9.1 then 'Half Rack'
		when max(Totmbps)/1024 between 9.1 and 18.2 then 'Full Rack'
		when max(Totmbps)/1024 > 18.2 then 'Full Rack+'
	end) exa_hc
	from (
 select (IOmbpsr + (&&num_addtl_dbs * &&pct_resource_load * &&margin_err * IOmbpsr)) IOmbpsr,
        (IOmbpsw + (&&num_addtl_dbs * &&pct_resource_load * &&margin_err * IOmbpsw)) IOmbpsw,
        (IOmbpsredo + (&&num_addtl_dbs * &&pct_resource_load * &&margin_err * IOmbpsredo)) IOmbpsredo,
        (Totmbps+ (&&num_addtl_dbs * &&pct_resource_load * &&margin_err * Totmbps)) Totmbps  from (
  select  snaps.id, snaps.tm,snaps.dur,snaps.instances,
        (((bs.db_block_size * (sysstat.IOmbpsr - lag (sysstat.IOmbpsr,1) over (order by snaps.id)))/1024/1024))/dur/60  IOmbpsr,
         decode(upper('&&asm_redundancy_data'),'NORMAL',2,'HIGH',3,2) *
		(((bs.db_block_size * (sysstat.IOmbpsw - lag (sysstat.IOmbpsw,1) over (order by snaps.id)))/1024/1024))/dur/60  IOmbpsw,
        decode(upper('&&asm_redundancy_reco'),'NORMAL',2,'HIGH',3,2) * 
		((((sysstat.IOmbpsredo - lag (sysstat.IOmbpsredo,1) over (order by snaps.id)))/1024/1024))/dur/60  IOmbpsredo,
        ((((bs.db_block_size * (sysstat.IOmbpsr - lag (sysstat.IOmbpsr,1) over (order by snaps.id)))/1024/1024))/dur/60) +
          (decode(upper('&&asm_redundancy_data'),'NORMAL',2,'HIGH',3,2) * 
		((((bs.db_block_size * (sysstat.IOmbpsw - lag (sysstat.IOmbpsw,1) over (order by snaps.id)))/1024/1024))/dur/60)) +
         (decode(upper('&&asm_redundancy_reco'),'NORMAL',2,'HIGH',3,2) * 
		(((((sysstat.IOmbpsredo - lag (sysstat.IOmbpsredo,1) over (order by snaps.id)))/1024/1024))/dur/60)) Totmbps
  from
  ( /* DBA_HIST_SNAPSHOT */
  select distinct id,dbid,tm,instances,max(dur) over (partition by id) dur from (
    select distinct s.snap_id id, s.dbid,
    to_char(s.end_interval_time,'DD-MON-RR HH24:MI') tm,
    count(s.instance_number) over (partition by snap_id) instances,
    1440*((cast(s.end_interval_time as date) - lag(cast(s.end_interval_time as date),1) over (order by s.snap_id))) dur
  from   dba_hist_snapshot s,
    v$database d
  where s.dbid=d.dbid)  
   ) snaps,
   ( /* DBA_HIST_SYSSTAT */
    select * from
        (select snap_id, dbid, stat_name, value from
        dba_hist_sysstat
    ) pivot
    (sum(value) for (stat_name) in
        ('logons current' as logons_curr, 'logons cumulative' as logons_cum, 'execute count' as execs,
	 'physical reads' as IOmbpsr, 'physical writes' as IOmbpsw,
	  'redo size' as IOmbpsredo))
   ) sysstat,
   ( /* V$PARAMETER */
    select value as db_block_size
    from v$parameter where name='db_block_size'
   ) bs
where dur > 0 
and snaps.id=sysstat.snap_id
and snaps.dbid=sysstat.dbid)
order by id asc)
/
undefine num_addtl_dbs
undefine pct_resource_load
undefine margin_err
undefine asm_redundancy_data
undefine asm_redundancy_reco

