REM Name: 	lst05-19-db-growth-horizon.sql
REM Purpose:  	Forecasts 1-year, 2-year, 3-year, and 5-year sizes
REM Usage: 	From DB Instance, SQL> @lst05-19-db-growth-horizon.sql

col 	curralloc 	format 99999990.90 head 'Curr |Alloc (GB)'
col 	grate 		format 99999.99 head 'Growth Rate|GB/day'
col 	year1		format 99999990.90 head '1-year|Size (GB)'
col 	year2		format 99999990.90 head '2-year|Size (GB)'
col 	year3		format 99999990.90 head '3-year|Size (GB)'
col 	year5		format 99999990.90 head '5-year|Size (GB)'

set lines 180
set pages 80
set trimspool on
set echo on
SELECT 
       ROUND (sum(curr_alloc_gb), 2) curralloc,
       greatest(sum(alloc_gbperday),sum(used_gbperday)) grate,
       (sum(curr_alloc_gb) + 
		365*(greatest(sum(alloc_gbperday),sum(used_gbperday))))
			-(sum(curr_alloc_gb)-sum(curr_used_gb)) year1,
       (sum(curr_alloc_gb) + 
		2*365*(greatest(sum(alloc_gbperday),sum(used_gbperday))))
			-(sum(curr_alloc_gb)-sum(curr_used_gb)) year2,
       (sum(curr_alloc_gb) + 
		3*365*(greatest(sum(alloc_gbperday),sum(used_gbperday))))
			-(sum(curr_alloc_gb)-sum(curr_used_gb)) year3,
       (sum(curr_alloc_gb) + 
		5*365*(greatest(sum(alloc_gbperday),sum(used_gbperday))))
			-(sum(curr_alloc_gb)-sum(curr_used_gb)) year5
  FROM (SELECT tsmin.tsname tbs, tsmin.tablespace_size init_alloc_gb,
               tsmin.tablespace_usedsize init_used_gb,
               tsmax.tablespace_size curr_alloc_gb,
               tsmax.tablespace_usedsize curr_used_gb,
                 (tsmax.tablespace_size - tsmin.tablespace_size) / (tsmax.snaptime - tsmin.snaptime) alloc_gbperday,
                 (tsmax.tablespace_usedsize - tsmin.tablespace_usedsize)
               / (tsmax.snaptime - tsmin.snaptime) used_gbperday          
        FROM   (SELECT *
                  FROM (SELECT TRUNC (s.begin_interval_time) snaptime,
                               t.tsname, (ts.BLOCKSIZE * u.tablespace_size) / 1024 / 1024 / 1024 tablespace_size,
                                 (ts.BLOCKSIZE * u.tablespace_usedsize) / 1024 / 1024 / 1024 tablespace_usedsize,
                               (RANK () OVER (PARTITION BY t.tsname ORDER BY s.snap_id ASC)
                               ) latest,
                               s.end_interval_time endtime
                          FROM dba_hist_snapshot s,
                               v$instance i, v$database d,
                               dba_hist_tablespace_stat t,
                               dba_hist_tbspc_space_usage u,
                               SYS.ts$ ts
                         WHERE s.snap_id = t.snap_id
                           AND s.dbid=d.dbid and s.dbid=t.dbid and s.dbid=u.dbid
			   AND i.instance_number = s.instance_number
                           AND s.instance_number = t.instance_number
                           AND ts.ts# = t.ts#
                           AND t.snap_id = u.snap_id
                           AND t.ts# = u.tablespace_id)
                 WHERE latest = 1) tsmin,
               (SELECT *
                  FROM (SELECT TRUNC (s.begin_interval_time) snaptime,
                               t.tsname,
                                 (ts.BLOCKSIZE * u.tablespace_size) / 1024 / 1024/  1024 tablespace_size,
                                 (ts.BLOCKSIZE * u.tablespace_usedsize) / 1024 / 1024 / 1024 tablespace_usedsize,
                               (RANK () OVER (PARTITION BY t.tsname ORDER BY s.snap_id DESC)
                               ) latest,
                               s.end_interval_time endtime
                          FROM dba_hist_snapshot s,
                               v$instance i, v$database d,
                               dba_hist_tablespace_stat t,
                               dba_hist_tbspc_space_usage u,
                               SYS.ts$ ts
                         WHERE s.snap_id = t.snap_id
    			   AND s.dbid=d.dbid and s.dbid=t.dbid and s.dbid=u.dbid
                           AND i.instance_number = s.instance_number
                           AND s.instance_number = t.instance_number
                           AND t.snap_id = u.snap_id
                           AND ts.ts# = t.ts#
                           AND t.ts# = u.tablespace_id)
                 WHERE latest = 1) tsmax
  WHERE tsmin.tsname = tsmax.tsname and tsmax.snaptime > tsmin.snaptime)
/
