REM Name: 	lst05-16-archive-size.sql
REM Purpose:  	Displays space requirements for archived redo logs
REM Usage: 	From DB Instance, SQL> @lst05-16-archive-size.sql

col AvgGBpd format 99999.99 head 'Avg GB per Day'
col MaxGBpd format 99999.99 head 'Max GB per Day'
col AvgReq format 99999.99 head 'GB Req Avg'
col MaxReq format 99999.99 head 'GB Req Max'
col cnt format 9999 head 'Number of files'
col szgb format 99990.99 head 'Size (GB)'
set lines 80
set echo on
select avg(gbpd) AvgGBpd, max(gbpd) MaxGBpd,
         avg(gbpd) * &&num_days AvgReq,
         max(gbpd) * &&num_days MaxReq
  from (
          select  al.dt,
                  (al.blks * kc.blksize)/1024/1024/1024 gbpd
          from
                  (select
                    trunc(completion_time) dt,
                    sum(blocks) blks
                  from v$archived_log
                  group by trunc(completion_time)) al,
                  (select
                     max(lebsz) blksize
                   from x$kccle) kc
  )
/
undefine num_days
