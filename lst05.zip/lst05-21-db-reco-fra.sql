REM Name: 	lst05-21-db-reco-fra.sql
REM Purpose:  	Determines how to size RECO and FRA on Exadata
REM Usage: 	From DB Instance, SQL> @lst05-21-db-reco-fra.sql
REM		backups_to_exa: Y or N, whether RMAN=>Exadata RECO
REM		use_flashlog: Y or N, whether to use Flashlog/Flashback 
REM		num_days: Number of days to retain archive logs on disk


col ArchMaxReq 	format 9999999.99 head 'ArchLog|Req.(GB)'
col dbgb 	format 9999999.99 head 'DB|Req.(GB)'
col redogb 	format 9999999.99 head 'OnlineLog|Req.(GB)'
col rmangb 	format 9999999.99 head 'RMAN|Req.(GB)'
col flgb 	format 9999999.99 head 'FlashLog|Req.(GB)'
col pct_for_data format 990.00 head '% for Data'
col pct_for_reco format 990.00 head '% for Reco/FRA'

set lines 180
set echo on

select dbgb, redogb, ArchMaxReq,
       rmangb,flgb,
       100*((dbgb+redogb)/(dbgb+redogb+ArchMaxReq+rmangb+flgb)) pct_for_data,
       100*((ArchMaxReq+redogb+rmangb+flgb)/(dbgb+redogb+ArchMaxReq+rmangb+flgb)) pct_for_reco
from 
 ( select 	db.dbgb, redo.redogb,
	(arch.gbpd * &&num_days) ArchMaxReq,
	(case
	  when upper('&&backups_to_exa') like 'Y%' then (db.dbgb + arch.gbpd)
	  else 0
	end) rmangb,
	(case
	  when upper('&&use_flashlog') like 'Y%' then (arch.gbpd)
	  else 0 
	end) flgb
 from (
	select 	
		avg((al.blks * kc.blksize)/1024/1024/1024) gbpd
	from
  		(select  
		  trunc(completion_time) dt,
                  sum(blocks) blks
   		 from v$archived_log
   		 group by trunc(completion_time)) al,
  		 (select 
		   max(lebsz) blksize
   		 from x$kccle) kc
      ) arch,
      (
	select sum(bytes)/1024/1024/1024 dbgb
       	from v$datafile
      ) db,
      (
	select sum(bytes)/1024/1024/1024 redogb
	from v$log
      ) redo     
)
/
undefine num_days
undefine backups_to_exa
undefine use_flashlog
