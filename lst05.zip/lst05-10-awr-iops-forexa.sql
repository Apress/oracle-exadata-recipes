REM Name: 	lst05-10-awr-iops-forexa.sql
REM Purpose: 	Retrieve Summarized IOPs-related metrics from AWR 
REM 		Report Exadata configuration
REM 	  : 	With extrapolations for number of instances, etc
REM Usage: 	From DB Instance, SQL> @lst05-10-awr-iops-forexa.sql


set arraysize 5000
set termout on
set echo off verify off
set lines 290
set pages 900
col id format 99999 head 'Snap|ID'
col tm format a15 head 'Snap|Start'
col instances format 999 head 'RAC|Nodes'
col dur format 999.99 head 'Duration|Mins'
col AvgIOPsr 	format 999990.00 	head 'Avg IOPs|Reads'
col AvgIOPsw 	format 999990.00 	head 'Avg IOPs|Write'
col AvgIOPsredo format 999990.00 	head 'Avg IOPs|Redo'
col AvgTotiops 	format 999990.00 	head 'Avg IOPs|Total'
col MaxIOPsr 	format 999990.00 	head 'Max IOPs|Reads'
col MaxIOPsw 	format 999990.00 	head 'Max IOPs|Write'
col MaxIOPsredo format 999990.00 	head 'Max IOPs|Redo'
col MaxTotiops 	format 999990.00 	head 'Max IOPs|Total'
col exa_hp 	format a30 		head 'Exadata Recommendaton|HP Disks'
col exa_hc 	format a30 		head 'Exadata Recommendaton|HC Disks'

set colsep "|"
set echo on
select 
	max(IOPsr) MaxIOPsr, 
	max(IOPsw) MaxIOPsw, 
	max(IOPsredo) MaxIOPsredo,
	max(Totiops) MaxTotiops,
	(case
	 when max(Totiops) < 10000 then 'Quarter Rack'
	 when max(Totiops) between 10000 and 25200 then 'Half Rack'
	 when max(Totiops) between 25200 and 50400 then 'Full Rack'
	 when max(Totiops) > 50400 then 'Full Rack+'
	end) exa_hp,
	(case
	 when max(Totiops) < 6000 then 'Quarter Rack'
	 when max(Totiops) between 6000 and 14000 then 'Half Rack'
	 when max(Totiops) between 14000 and 28000 then 'Full Rack'
	 when max(Totiops) > 28000 then 'Full Rack+'
	end) exa_hc
from (
select 
	(IOPsr + (&&num_addtl_dbs * &&pct_resource_load * &&margin_err * IOPsr)) IOPsr,
	(IOPsw + (&&num_addtl_dbs * &&pct_resource_load * &&margin_err * IOPsw)) IOPsw,
	(IOPsredo + (&&num_addtl_dbs * &&pct_resource_load * &&margin_err * IOPsredo)) IOPsredo,
	(Totiops+ (&&num_addtl_dbs * &&pct_resource_load * &&margin_err * Totiops)) Totiops from (
select  snaps.id, snaps.tm,snaps.dur,snaps.instances,
        ((sysstat.IOPsr - 
		lag (sysstat.IOPsr,1) over (order by snaps.id)))/dur/60  IOPsr,
        decode(upper('&&asm_redundancy_data'),'NORMAL',2,'HIGH',3,2) * ((sysstat.IOPsw - 
		lag (sysstat.IOPsw,1) over (order by snaps.id)))/dur/60  IOPsw,
        decode(upper('&&asm_redundancy_reco'),'NORMAL',2,'HIGH',3,2) * ((sysstat.IOPsredo - 
		lag (sysstat.IOPsredo,1) over (order by snaps.id)))/dur/60  IOPsredo,
        (((sysstat.IOPsr - 
		lag (sysstat.IOPsr,1) over (order by snaps.id)))/dur/60) + 
        (decode(upper('&&asm_redundancy_data'),'NORMAL',2,'HIGH',3,2) * (((sysstat.IOPsw - 
		lag (sysstat.IOPsw,1) over (order by snaps.id)))/dur/60)) + 
        (decode(upper('&&asm_redundancy_reco'),'NORMAL',2,'HIGH',3,2) * (((sysstat.IOPsredo - 
		lag (sysstat.IOPsredo,1) over (order by snaps.id)))/dur/60)) Totiops,
        sysstat.logons_curr ,
        ((sysstat.logons_cum - 
		lag (sysstat.logons_cum,1) over (order by snaps.id)))/dur/60  logons_cum,
        ((sysstat.execs - 
		lag (sysstat.execs,1) over (order by snaps.id)))/dur/60 execs
 from
 ( /* DBA_HIST_SNAPSHOT */
 select distinct id,dbid,tm,instances,max(dur) over (partition by id) dur from (
 select distinct s.snap_id id, s.dbid,
    to_char(s.end_interval_time,'DD-MON-RR HH24:MI') tm,
    count(s.instance_number) over (partition by snap_id) instances,
    1440*((cast(s.end_interval_time as date) - lag(cast(s.end_interval_time as date),1) over (order by s.snap_id))) dur
 from   dba_hist_snapshot s,
    v$database d
 where s.dbid=d.dbid)
 ) snaps,
  ( /* DBA_HIST_SYSSTAT */
    select * from
        (select snap_id, dbid, stat_name, value from
        dba_hist_sysstat
    ) pivot
    (sum(value) for (stat_name) in
        ('logons current' as logons_curr, 'logons cumulative' as logons_cum, 'execute count' as execs,
	 'physical read IO requests' as IOPsr, 'physical write IO requests' as IOPsw,
	  'redo writes' as IOPsredo))
  ) sysstat
where dur > 0 
and snaps.id=sysstat.snap_id
and snaps.dbid=sysstat.dbid)
order by id asc)
/

undefine num_addtl_dbs
undefine pct_resource_load
undefine margin_err
undefine asm_redundancy_data
undefine asm_redundancy_reco

