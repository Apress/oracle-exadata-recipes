#!/bin/bash
# Name: lst12-03-setup-osusers.sh
export PASSWD=welcome1
export USER_LIST="userprod usertest userdev"
# Set USER_ID to the next available id from /etc/passwd or an unused value
export USER_ID=3004
#
for username in `echo $USER_LIST`
do
useradd ${username} -u ${USER_ID} -d /home/${username}
echo "$username:$PASSWD" | chpasswd
(( USER_ID+=1 ))
done
