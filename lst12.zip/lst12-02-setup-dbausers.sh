#!/bin/bash
# Name: lst12-02-setup-dbausers.sh
export PASSWD=welcome1
export USER_LIST="oraprod oratest oradev"
export USER_ID=3001
export LC=/etc/security/limits.conf
cp $LC ${LC}_`date +%Y-%m-%d_%H:%M:%S`
#
for username in `echo $USER_LIST`
do
export user_suffix=`echo $username | cut -f2 -da`
useradd -u ${USER_ID} -g oinstall -G dba_${user_suffix},oinstall,asmdba -d /home/${username} ${username}
echo "${username}:${PASSWD}" | chpasswd
chown -R ${username}:oinstall /home/${username}
echo " " >> ${LC}
echo "$username soft core unlimited" >> $LC
echo "$username soft core unlimited" >> $LC
echo "$username soft nproc 131072" >> $LC
echo "$username hard nproc 131072" >> $LC
echo "$username soft nofile 131072" >> $LC
echo "$username hard nofile 131072" >> $LC
echo "$username soft memlock 55520682" >> $LC
echo "$username hard memlock 55520682" >> $LC
(( USER_ID+=1 ))
done

