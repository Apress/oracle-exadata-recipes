#!/bin/sh
# Name: lst12-04-gen-db-sec.sh

dcli -g ./cell_group -l celladmin "cellcli -e list griddisk where name  \
like \'$1.*\'" | awk -F: '{print $1 " " $2}' | awk '{print "dcli -c  \
" $1 " -l celladmin \"cellcli -e alter griddisk " $2 " availableTo="  \
"\x5c\x27" "+ASM,'$2'" "\x5c\x27" "\""}'
