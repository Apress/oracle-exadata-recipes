#!/bin/sh -x
# Name: lst12-01-setup-osgroups.sh
groupadd dba_prod -g 1010
groupadd dba_test -g 1011
groupadd dba_dev -g 1012
groupadd oraprod -g 1110
groupadd oratest -g 1111
groupadd oradev -g 1112
