REM Name:    lst15-05-exass-vsql.sql
REM Purpose: Display cell offload and I/O info from v$sql
REM Usage: SQL> @lst15-05-exass-vsql.sql

set pagesize 999
set lines 190
col sql_id format a13 head 'SqlID'
col child_number format 999 head 'ChildNo'
col sql_text format a40 head 'SqlText' trunc
col avgelapsed format 99,999.99 head 'AvgSecs'
col eligible format a10 head 'Offloaded'
col icgb format 999,999.99 head 'IO(GB)'
col ssgb format 999,999.99 head 'SS(GB)'
select sql_id, child_number,
  (elapsed_time/1000000)/
     executions/
      decode(px_servers_executions,0,1,px_servers_executions) avgelapsed,
  decode(io_cell_offload_eligible_bytes,0,'No','Yes') eligible,
  io_interconnect_bytes/1024/1024/1024 icgb,
  io_cell_offload_returned_bytes/1024/1024/1024 ssgb,
  sql_text
from gv$sql s
where sql_id='&&sql_id'
order by 1, 2, 3
/
undefine sql_id
