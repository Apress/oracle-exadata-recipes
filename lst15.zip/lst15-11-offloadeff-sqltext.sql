REM Name:    lst15-11-offloadeff-sqltext.sql
REM Purpose: Display Offload efficiency for named SQL texts
REM Usage:   SQL> @lst15-11-offloadeff-sqltext.sql
set lines 200
col sql_id format a13 head 'SqlID'
col sql_text format a32 head 'SqlText'
col offload1 format 999.90 head 'EstOffloadEfficiency%'
col offload2 format 999.90 head 'TrueOffloadEfficiency%'
set echo on
select  sql_id ,
        (case when io_cell_offload_eligible_bytes = 0 then 0
           else 100*(1-(io_interconnect_bytes/io_cell_offload_eligible_bytes))
        end) offload1,
        (case when phybytes = 0 then 0
           else 100*(1-(io_interconnect_bytes/phybytes))
        end) offload2,
	sql_text
from (
 select  sql_id,
        physical_read_bytes+physical_write_bytes phybytes,
	io_cell_offload_eligible_bytes,
	io_interconnect_bytes, sql_text
 from v$sql
 where sql_text like '%full (t)%' and 
 sql_text not like '%sql_id%')
;
undefine sqlid
