REM Name:    lst15-03-exass-mysess.sql 
REM Purpose: Display smart scan statistics from your session
REM Usage: SQL> @lst15-03-exass-mysess.sql

set lines 200
col instance_name format a10 head 'Instance'
col name format a70 head 'Statistic'
col value format 999,999,999,999,999 head 'Value (GB)'
col stat format a20
select stat.name,
       round(sess.value/1024/1024/1024,2) value
from   v$mystat sess,
       v$statname stat
where  stat.statistic# = sess.statistic#
  and stat.name in 
   ('cell physical IO bytes eligible for predicate offload',
     'cell physical IO interconnect bytes',
     'cell physical IO interconnect bytes returned by smart scan')
order by 1
/
undefine sid
