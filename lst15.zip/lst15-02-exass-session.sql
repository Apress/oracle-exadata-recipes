REM Name: lst15-02-exass-session.sql
REM Purpose: Display smart scan statistics for a session
REM Usage: SQL> @lst15-02-exass-session.sql

set lines 200
col sid format 9999 head 'SID'
col instance_name format a10 head 'Instance'
col name format a70 head 'Statistic'
col value format 999,999,999,999,999 head 'Value (GB)'
col stat format a20
select sess.sid,
       stat.name,
       round(sess.value/1024/1024/1024,2) value
from   v$sesstat sess,
       v$statname stat
where  stat.statistic# = sess.statistic#
  and  sess.sid = '&&sid' 
  and stat.name in 
   ('cell physical IO bytes eligible for predicate offload',
     'cell physical IO interconnect bytes',
     'cell physical IO interconnect bytes returned by smart scan')
union
select -1,
	stat.name,
       round(sum(sess.value)/1024/1024/1024,2) value
from   v$sesstat sess,
       v$statname stat
where  stat.statistic# = sess.statistic#
  and  sess.sid  in (select sid from v$px_session where qcsid='&&sid')
  and stat.name in
   ('cell physical IO bytes eligible for predicate offload',
     'cell physical IO interconnect bytes',
     'cell physical IO interconnect bytes returned by smart scan')
group by stat.name
order by 1 desc,2
/
undefine sid
