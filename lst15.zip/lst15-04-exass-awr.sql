REM Name:    lst15-04-exass-awr.sql
REM Purpose: Display smart scan statistics from AWR snapshots
REM Usage: SQL> @lst15-04-exass-awr.sql

set lines 200
col stime format a15 head 'SnapStart'
col icgb format 999999999 head 'InterconnectGB'
col eliggb format 999999999 head 'SmartScanEligibleGB'
col ssgb format 999999999 head 'SmartScanReturnedBytes'
select stime,icgb,eliggb,ssgb from (
select  distinct 
  to_char(snap.begin_interval_time,'DD-MON-RR HH24:MI') stime,
  snaps.icbytes/1024/1024/1024 icgb,
  snaps.eligbytes/1024/1024/1024 eliggb, 
  snaps.ssbytes/1024/1024/1024 ssgb,
  myrank
from (
select ss1.snap_id,
       (sum(ss1.value) - lag(sum(ss1.value),1,0) over (order by ss1.snap_id)) icbytes,
       (sum(ss2.value) - lag(sum(ss2.value),1,0) over (order by ss2.snap_id)) eligbytes,
       (sum(ss3.value) - lag(sum(ss3.value),1,0) over (order by ss3.snap_id)) ssbytes,
	rank() over (order by ss1.snap_id) myrank
from
     dba_hist_sysstat ss1,
     dba_hist_sysstat ss2,
     dba_hist_sysstat ss3
where ss1.snap_id=ss2.snap_id
and ss2.snap_id=ss3.snap_id
and ss1.snap_id between &&snap_low-1 and &&snap_hi
and ss2.dbid=ss1.dbid
and ss3.dbid=ss2.dbid
and ss1.stat_name='cell physical IO interconnect bytes'
and ss2.stat_name='cell physical IO bytes eligible for predicate offload'
and ss3.stat_name='cell physical IO interconnect bytes returned by smart scan'
group by ss1.snap_id,ss2.snap_id,ss3.snap_id
order by ss1.snap_id) snaps,
dba_hist_snapshot snap
where snap.snap_id=snaps.snap_id
order by 1)
where myrank>1;
undefine snap_low
undefine snap_hi
