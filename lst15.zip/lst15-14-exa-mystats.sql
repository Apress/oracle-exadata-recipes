REM Name:    lst15-14-exa-mystats.sql
REM Purpose: Display smart scan statistics from your session
REM Usage: SQL> @lst15-14-exa-mystats.sql

set lines 200
col stat format a40 head 'Event'
col time_waited format 999,999,999,999 head 'TimeWaited'
col total_waits format 999,999,999,999 head 'TotalWaits'
set echo on
select  stat,sum(time_waited) time_waited,
	sum(total_waits) total_waits
from
  (select c.event stat, c.time_waited,c.total_waits
   from  v$session b, v$session_event c
   where c.sid=b.sid
   and c.event like 'cell%'
   and b.sid=userenv('sid'))
   group by stat
   having sum(time_waited) > 0
order by 2 desc;
col instance_name format a10 head 'Instance'
col name format a70 head 'Statistic'
col value format 999,999,999,999,999 head 'Stat Value'
col stat format a20
select stat.name,
       sess.value value
from   v$mystat sess,
       v$statname stat
where  stat.statistic# = sess.statistic#
  and stat.name in 
   ('cell physical IO bytes eligible for predicate offload',
     'cell physical IO interconnect bytes','table fetch continued row',
     'cell physical IO interconnect bytes returned by smart scan')
order by 1;
undefine sid
