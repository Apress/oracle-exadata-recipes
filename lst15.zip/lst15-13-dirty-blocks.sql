REM Name:    lst15-13-dirty-blocks.sql
REM Purpose: Report the number of dirty blocks for an object
REM Usage:   SQL> @lst15-13-dirty-blocks.sql

set lines 200
col owner format a10 head 'Owner'
col object_name format a35 head 'Object'
col partition_name format a35 head 'Partition'
col dirty format 999,999,999 head 'DirtyBlks'
col dirtypct format 999.90 head 'Dirty%'

set echo on
select object.object_name, object.partition_name,object.dirty dirty,
 100*(object.dirty/seg.blocks) dirtypct 
from 
(select owner,object_name,subobject_name partition_name,count(1) dirty
    from dba_objects obj, v$bh bh
    where obj.data_object_id=bh.objd
    and upper(obj.object_name)=upper('&&object_name')
    and upper(obj.owner)=upper('&&owner')
    and bh.dirty='Y'
   group by owner,object_name,subobject_name) object,
(select owner,segment_name,partition_name,blocks
  from dba_segments
  where upper(owner)=upper('&&owner') and upper(segment_name)=upper('&&object_name')) seg
where object.owner=seg.owner and object.object_name=seg.segment_name
and nvl(object.partition_name,'ZZZ')=nvl(seg.partition_name,'ZZZ');

undefine owner
undefine object_name
