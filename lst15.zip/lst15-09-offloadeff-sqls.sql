REM Name:    lst15-09-offloadeff-sqls.sql
REM Purpose: Display offload efficiencies for Top N
REM Usage:   SQL> @lst15-09-offloadeff-sqls.sql

col sql_id format a13 head 'SqlID'
col offload1 format 999.90 head 'EstOffloadEfficiency%'
col offload2 format 999.90 head 'TrueOffloadEfficiency%'
col avgelapsed format 999,999,999.00 head 'AvgElaspedSecs'
set echo on
select  sql_id ,avgelapsed,
        (case when io_cell_offload_eligible_bytes = 0 then 0
           else 100*(1-(io_interconnect_bytes/io_cell_offload_eligible_bytes))
        end) offload1,
        (case when phybytes = 0 then 0
           else 100*(1-(io_interconnect_bytes/phybytes))
        end) offload2
from (
 select  sql_id,
        physical_read_bytes+physical_write_bytes phybytes,
	io_cell_offload_eligible_bytes,
	io_interconnect_bytes,
	(elapsed_time/1000000)/
        executions/
         decode(px_servers_executions,0,1,px_servers_executions) avgelapsed
 from v$sql
 where executions > 0
 order by avgelapsed desc)
where rownum < &&rows_to_display + 1
;
undefine rows_to_display
