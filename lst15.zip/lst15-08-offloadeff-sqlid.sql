REM Name:    lst15-08-offloadeff-sqlid.sql
REM Purpose: Display Offload efficiency for SQL ID
REM Usage:   SQL> @lst15-08-offloadeff-sqlid.sql

col sql_id format a13 head 'SqlID'
col offload1 format 999.90 head 'EstOffloadEfficiency%'
col offload2 format 999.90 head 'TrueOffloadEfficiency%'
set echo on
select  sql_id ,
        (case when io_cell_offload_eligible_bytes = 0 then 0
           else 100*(1-(io_interconnect_bytes/io_cell_offload_eligible_bytes))
        end) offload1,
        (case when phybytes = 0 then 0
           else 100*(1-(io_interconnect_bytes/phybytes))
        end) offload2
from (
 select  sql_id,
        physical_read_bytes+physical_write_bytes phybytes,
	io_cell_offload_eligible_bytes,
	io_interconnect_bytes
 from v$sql
 where sql_id='&&sqlid')
;
undefine sqlid
