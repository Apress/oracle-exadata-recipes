REM Name: lst15-01-exass-system.sql
REM Purpose: Display smart scan statistcis system-wide
REM Usage: SQL> @lst15-01-exass-system.sql

set lines 200
col instance_name format a10 head 'Instance'
col name format a70 head 'Statistic'
col value format 999,999,999,999,999 head 'Value (GB)'
col stat format a20
select  inst.instance_name,
	b.name,
        a.value/1024/1024/1024 value
from   gv$sysstat a,
       gv$statname b, gv$instance inst
where  a.statistic# = b.statistic#
and b.name in 
	('cell physical IO bytes eligible for predicate offload',
         'cell physical IO interconnect bytes',
         'cell physical IO interconnect bytes returned by smart scan')
and inst.inst_id=a.inst_id
and inst.inst_id=b.inst_id
order by 1,2
/
