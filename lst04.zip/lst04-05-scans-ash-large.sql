REM Name: 	lst04-05-scans-ash-large.sql
REM Purpose: 	Display full scan statistics from ASH for large segs
REM Usage: 	From DB Instance, SQL> @lst04-05-scans-ash-large.sql

col sql_id format a15 head 'SQL ID'
col sqlop format a35 head 'Operation + Options'
col seg format a45 head 'Segment'
col dbt format 99999990.90 head 'Time spent (Secs)'
col blocks format 9999999  head 'Blocks'
set pages 80
set lines 145
set echo on
select sql_id,sql_plan_operation||' '||sql_plan_options sqlop,
       owner||'.'||object_name seg, blocks,
       sum(sql_secs_per_snap)/60 dbt
        from (
SELECT ash.snap_id,ash.sample_id,ash.sql_id,
       ash.sql_plan_operation, ash.sql_plan_options,
       obj.owner, obj.object_name,
       10*(count(sample_id) over
                (partition by ash.sql_id,ash.snap_id)) sql_secs_per_snap,
       seg.blocks
  FROM dba_hist_active_sess_history ash,
       dba_objects obj,
       dba_segments seg
 WHERE ash.wait_class = 'User I/O'
   AND (( ash.sql_plan_operation = 'TABLE ACCESS' AND ash.sql_plan_options LIKE '%FULL%')
        OR ( ash.sql_plan_operation = 'INDEX' AND ash.sql_plan_options LIKE '%FAST%FULL%')
       )
  and obj.object_id=ash.current_obj#
  and obj.owner not in ('SYS','SYSTEM')
  and obj.object_type in ('TABLE','INDEX')
  and obj.object_name=seg.segment_name
  and obj.owner=seg.owner
  and seg.blocks >
(
   select .02 * ((&&target_cache_size_gb*1024*1024*1024)/&&target_db_blk_size)
   from dual
 )
  )
  group by sql_id,sql_plan_operation, sql_plan_options,
       owner, object_name,blocks
order by 5 desc
/

undefine target_cache_size_db
undefine target_db_blk_size

