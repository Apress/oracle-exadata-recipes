REM Name: 	lst04-08-hcc-candidate.sql
REM Purpose: 	Display potential HCC candidates
REM Usage: 	From DB Instance, SQL> @lst04-08-hcc-candidate.sql

col owner format a15 head 'Owner'
col segment_name format a28 head 'Segment'
col partition_name format a10 head 'Partition'
col pctofdb format 999.99 head '% of DB Size'
col gb format 9999.99 head 'Size (GB)'
set lines 120
set echo on
select 	owner,segment_name,
	segment_type,partition_name,bytes/1024/1024/1024 gb,
	round(100*(bytes/totbytes),2) pctofdb
	from (
		select owner,
			segment_name,
			segment_type,partition_name,
			bytes,(sum(bytes) over ()) totbytes
		from dba_segments order by 4 asc
)
where 100*(bytes/totbytes) > 2 --- where size > 2% the size of the database
order by 5 desc
/

