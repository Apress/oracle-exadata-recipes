REM Name: 	lst04-04-scans-ash.sql
REM Purpose: 	Display full scan statistics from ASH 
REM Usage: 	From DB Instance, SQL> @lst04-04-scans-ash.sql

col sql_id format a15 head 'SQL ID'
col sqlop format a35 head 'Operation + Options'
col seg format a45 head 'Segment'
col dbt format 99999990.90 head 'Time spent (Secs)'
set pages 80
set lines 145
set echo on
select sql_id,sql_plan_operation||' '||sql_plan_options sqlop,
       owner||'.'||object_name seg,
       sum(sql_secs_per_snap)/60 dbt from (
SELECT ash.snap_id,ash.sample_id,ash.sql_id,
       ash.sql_plan_operation, ash.sql_plan_options, obj.owner, obj.object_name,
       10*(count(sample_id) over (partition by ash.sql_id,ash.snap_id)) sql_secs_per_snap
  FROM dba_hist_active_sess_history ash,
       dba_objects obj
 WHERE ash.wait_class = 'User I/O'
   AND (   (    ash.sql_plan_operation = 'TABLE ACCESS'
            AND ash.sql_plan_options LIKE '%FULL%'
           )
        OR (    ash.sql_plan_operation = 'INDEX'
            AND ash.sql_plan_options LIKE '%FAST%FULL%'
           )
       )
  and obj.object_id=ash.current_obj#
  and obj.owner not in ('SYS','SYSTEM')
  and obj.object_type in ('TABLE','INDEX')
  )
  group by sql_id,sql_plan_operation, sql_plan_options,
       owner, object_name
order by 4 desc

