REM Name: 	lst04-07-create-sqlset.sql
REM Purpose: 	Creates SQL Tuning Set
REM          	involving offload-supported operations
REM Usage: 	From DB Instance, SQL> @lst04-07-create-sqlset.sql

exec DBMS_SQLTUNE.CREATE_SQLSET('&&sql_set');
declare
  baseline_ref_cursor DBMS_SQLTUNE.SQLSET_CURSOR;
begin
  open baseline_ref_cursor for
   select VALUE(p)
   from table(DBMS_SQLTUNE.SELECT_WORKLOAD_REPOSITORY(&&snap_low,&&snap_high,      
       NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL')) p;
   DBMS_SQLTUNE.LOAD_SQLSET('&&sql_set', baseline_ref_cursor);
end;
/

begin
     dbms_sqltune.create_sqlset(sqlset_name=>'&&sql_set',
            description=>'&&sql_set_description');
end;
/

begin
      dbms_sqltune.capture_cursor_cache_sqlset (
        sqlset_name     => '&&sql_set',
        time_limit      => &&time_limit,
        repeat_interval => &&repeat_interval
      );
end;
/


undefine sql_set
undefine sql_set_description
undefine time_limit
undefine repeat_interval


