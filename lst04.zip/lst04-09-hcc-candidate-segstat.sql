REM Name: 	lst04-09-hcc-candidate-segstat.sql
REM Purpose: 	Display potential HCC candidates with DML Segment Stats
REM Usage: 	From DB Instance, SQL> @lst04-09-hcc-candidate-segstat.sql

col owner format a15 head 'Owner'
col segment_name format a25 head 'Segment'
col partition_name format a10 head 'Partition'
col pctofdb format 999.99 head '% of DB Size'
col gb format 9999.99 head 'Size (GB)'
col pwrites format 9999999999 head 'Phys Writes'
col blkchanges format 9999999999 head 'Block Changes'

set lines 120
set echo on
select 	seg.owner,seg.segment_name,
	seg.segment_type,seg.partition_name,seg.bytes/1024/1024/1024 gb,
	round(100*(seg.bytes/seg.totbytes),2) pctofdb,
	nvl(sum(segstat.pwrites),0) pwrites, nvl(sum(segstat.blkchanges),0) blkchanges
	from (
		select owner,
			segment_name,
			segment_type,partition_name,
			bytes,(sum(bytes) over ()) totbytes
		from dba_segments order by 4 asc) seg,
	     (
		select obj.owner,obj.object_name,obj.object_id,
		       obj.data_object_id, sum(physical_writes_delta) pwrites,
				sum(db_block_changes_delta) blkchanges
	 	from dba_objects obj, dba_hist_seg_stat ss
	        where obj.object_id=ss.obj#(+)
	        and obj.data_object_id=ss.dataobj#(+)
	 	group by obj.owner,obj.object_name,obj.object_id,obj.data_object_id
 	     ) segstat
where 100*(seg.bytes/seg.totbytes) > 2 --- where size > 2% the size of the database
and seg.owner=segstat.owner
and seg.segment_name=segstat.object_name
group by seg.owner, seg.segment_name,seg.segment_type,seg.partition_name,seg.bytes,
seg.totbytes
order by 5 desc
/

