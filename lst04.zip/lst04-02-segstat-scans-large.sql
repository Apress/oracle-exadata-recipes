REM Name: 	lst04-02-segstat-scans-large.sql
REM Purpose: 	Display full scan statistics from DBA_HIST_SEG_STAT for large objects
REM        : 	"Large" = blocks > _small_table_threshold
REM Usage: 	From DB Instance, SQL> @lst04-02-segstat-scans-large.sql

col owner format a15 head 'Owner'
col table_name format 35 head 'Segment'
col cnt format 999999999 head 'Table Scans'
set lines 80
set linesize 80
set echo on
select * from (
	select tab.owner,
		tab.table_name,
		count(ss.table_scans_delta) cnt
	from 	dba_tables tab,
	dba_hist_seg_stat ss,
	dba_objects obj
	where ss.obj#=obj.object_id
	and obj.object_type in
	('TABLE','TABLE PARTITION','TABLE SUBPARTITION')
	and tab.table_name=obj.object_name
	and tab.blocks >=
		(
		select .02 * 
		 ((&&cache_size_gb*1024*1024*1024)/&&db_blk_size)
		from dual
		)
	group by tab.owner,tab.table_name
	order by 3 desc)
where rownum < &&display_rows
/
undefine display_rows
