REM Name: 	lst04-06-scans-sqlplans-large-supp.sql
REM Purpose: 	Display full scan statistics V$SQL_PLAN for large objects
REM          	involving offload-supported operations
REM Usage: 	From DB Instance, SQL> @lst04-06-scans-sqlplans-large-supp.sql

col sql_id format a15 head 'SQL_ID'
col obj format a35 head 'Object'
col op format a40 head 'Operation + Options'
set lines 120
set echo on

select 	s.sql_id,
	s.object_owner||'.'||s.object_name obj,
	s.operation||' '||s.options op
from 	v$sql_plan s,
	dba_segments seg
where 	s.options like '%FULL%'
and  	s.object_name=seg.segment_name
and  	s.object_owner=seg.owner
and 	seg.blocks >
	(
	select .02 * ((&&cache_size_gb*1024*1024*1024)/&&db_blk_size)
	from dual
	)
and not exists
	(
	select 'x'
	from v$sqlfn_metadata md
	where md.offloadable='NO'
	and nvl(instr(s.filter_predicates,md.name),0) > 0
	)
order by s.sql_id,s.position
/
undefine cache_size_db
undefine db_blk_size
