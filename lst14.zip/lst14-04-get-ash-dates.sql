REM Name:   lst14-04-get-ash-dates.sql
REM Purpose: Gather dates to use in ASH queries
REM Usage: @lst14-04-get-ash-dates.sql
set echo off verify off timing off feedback off trimspool on trimout on 
set long 1000000 pagesize 6000 linesize 80
define ash_time_format = 'DD-Mon-YY HH24:MI:SS';
define default_report_type         = 'html';
define default_report_duration     = 15;
define default_report_name_suffix  = 'MMDD_HH24MI';
prompt Enter begin time for report:
prompt --    Valid input formats:
prompt --      To specify absolute begin time:
prompt --        [MM/DD[/YY]] HH24:MI[:SS] 
prompt --        Examples: 02/23/03 14:30:15
prompt --                  02/23 14:30:15
prompt --                  14:30:15
prompt --                  14:30
prompt --      To specify relative begin time: (start with '-' sign)
prompt --        -[HH24:]MI                
prompt --        Examples: -1:15  (SYSDATE - 1 Hr 15 Mins)
prompt --                  -25    (SYSDATE - 25 Mins)
prompt Defaults to -&&default_report_duration mins
prompt Report begin time specified: &&begin_time
--  Set up the binds for btime
whenever sqlerror exit;
variable btime varchar2(30);
declare
  lbtime_in         varchar2(100);
  begin_time        date;
  FUNCTION get_time_from_begin_time( btime_in IN VARCHAR2 )
    RETURN DATE
  IS
    first_char    VARCHAR2(2);
    in_str        VARCHAR2(100);
    past_hrs      NUMBER;
    past_mins     NUMBER;
    pos           NUMBER;
    num_slashes   NUMBER := 0;
    num_colons    NUMBER := 0;
    date_part     VARCHAR2(100);
    time_part     VARCHAR2(100);
    my_fmt        VARCHAR2(100) := 'MM/DD/YY HH24:MI:SS';
  BEGIN
    in_str := TRIM(btime_in);
    first_char := SUBSTR(in_str, 1, 1);
    IF (first_char = '-') THEN
      in_str := SUBSTR(in_str, 2);
      pos := INSTR(in_str,':');
      IF (pos = 0) THEN
        past_hrs := 0;
        past_mins := TO_NUMBER(in_str);
      ELSE
        past_hrs := TO_NUMBER(SUBSTR(in_str,1,pos-1));
        past_mins := TO_NUMBER(SUBSTR(in_str,pos+1));
      END IF;
      
      IF (past_mins = 0 AND past_hrs = 0) THEN
        /* Invalid input */
        raise_application_error( -20500, 'Invalid input! Cannot recognize ' ||
                                 'input format for begin_time ' || '"' || 
                                 TRIM(btime_in) || '"' );
        RETURN NULL;
      END IF;
      RETURN (sysdate - past_hrs/24 - past_mins/1440);
    END IF;
    FOR pos in 1..LENGTH(in_str) LOOP
      IF (SUBSTR(in_str,pos,1) = '/') THEN
        num_slashes := num_slashes + 1;
      END IF;
      IF (SUBSTR(in_str,pos,1) = ':') THEN
        num_colons := num_colons + 1;
      END IF;
    END LOOP;
    IF (num_slashes > 0) THEN
      pos := INSTR(in_str,' ');
      date_part := TRIM(SUBSTR(in_str,1,pos-1));
      time_part := TRIM(SUBSTR(in_str,pos+1));
      IF (num_slashes = 1) THEN
        date_part := date_part || '/' || TO_CHAR(sysdate,'YY');
      END IF;
    ELSE
      date_part := TO_CHAR(sysdate,'MM/DD/YY');
      time_part := in_str;
    END IF;
    IF (num_colons > 0) THEN
      IF (num_colons = 1) THEN
        time_part := time_part || ':00';
      END IF;
      in_str := date_part || ' ' || time_part;
      begin
        RETURN TO_DATE(in_str, my_fmt);
      exception
        when others then
        raise_application_error( -20500, 'Invalid input! Cannot recognize ' ||
                                 'input format for begin_time ' || '"' || TRIM(btime_in) || '"' );
      end;
    END IF;
    /* Invalid input */
    raise_application_error( -20500, 'Invalid input! Cannot recognize ' ||
                             'input format for begin_time ' || '"' || TRIM(btime_in) || '"' );
    RETURN NULL;
  END get_time_from_begin_time;
begin
  lbtime_in  := nvl('&&begin_time', '-' || &&default_report_duration);
  begin_time := get_time_from_begin_time(lbtime_in);
  :btime := to_char( begin_time, '&&ash_time_format' );
end;
/
whenever sqlerror continue;
prompt Enter duration in minutes starting from begin time: 
prompt Defaults to SYSDATE - begin_time 
prompt Press Enter to analyze till current time
prompt Report duration specified:   &&duration
variable etime varchar2(30);
declare
  duration          number;
  since_begin_time  number;
  begin_time        date;
  end_time          date;
begin
  begin_time := to_date( :btime, '&&ash_time_format' );
  since_begin_time := (sysdate - begin_time)*1440;
  duration   := nvl('&&duration', since_begin_time);
  if (duration > since_begin_time) then
    duration := since_begin_time;
  end if;
  end_time := begin_time + duration/1440;
  :etime := to_char( end_time, '&&ash_time_format' );
end;
/
column nl80 format a80 newline;
set heading off
select 'Using ' || :btime || ' as report begin time' as nl80,
       'Using ' || :etime || ' as report end time' as nl80
from   dual;
set heading on
undefine default_report_type;
undefine default_report_duration;
undefine default_report_name_prefix;
undefine default_report_name_suffix;
undefine ash_time_format
