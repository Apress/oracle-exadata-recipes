REM Name: lst14-10-exawait-sess.sql 
REM Purpose: Display Exadata wait events from v$session
REM Usage: SQL> @lst14-10-exawait-sess.sql

set linesize 200 pages 55
col sid format 99999 head 'Sess'
col inst_id format 999 head 'Inst'
col cell_path format a30 head 'Cell'
col path format a30 head 'Disk'
col program format a25
col pgm format a15 head 'PgmModAct'
col state format a15
col wt format 9999999 head 'WaitTime'
col event format a25 head 'Wait Event'
col asm_disk format a30 head 'ASMDisk'
col p3 format 999999999 head 'BytesOrBlocks'
select 	sess.inst_id,sess.sid,sess.sql_id,
	sess.event event,
        cell.cell_path,
        (case when event like '%block%' 
  	then (select path from v$asm_disk where hash_value=sess.p2)
        else 'N/A'
 	end) asm_disk,
        p3,
	decode(sess.state,'WAITING',sess.seconds_in_wait,
		'WAITED UNKNOWN TIME',-999, 'WAITED SHORT TIME',sess.wait_time,
		'WAITED KNOWN TIME',sess.wait_time) wt,
	substr(nvl(sess.module,sess.program),1,15) pgm
from    gv$session sess,
	v$cell cell
where   sess.state in ('WAITING','WAITED KNOWN TIME')
and     sess.status='ACTIVE'
and     sess.event like 'cell%'
and     sess.p1=cell.cell_hashval
order by 8 desc
/

