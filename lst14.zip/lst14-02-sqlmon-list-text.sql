REM Name: lst14-03-sqlmon-list-text.sql
REM Purpose: Display current SQL Monitoring report
REM Usage: @lst14-03-sqlmon-list-text.sql


set pagesize 0 echo on timing off 
set linesize 1000 trimspool on trim on 
set long 2000000 longchunksize 2000000
select dbms_sqltune.report_sql_monitor_list(
type=>'TEXT',
report_level=>'ALL') as report  
from dual;

