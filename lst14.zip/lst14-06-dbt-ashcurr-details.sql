REM Name:    lst14-07-dbt-ashcurr-details.sql
REM Purpose: Display DB time and AAS by SQL ID
REM Usage:   @lst14-07-dbt-ashcurr-details.sql
set lines 140 pages 100 arraysize 4000
set verify on timing on feed on trimspool off trimout on
col samplestart format a19 head 'Begin Time'
col sql_id format a15 head 'SQL ID'
col tc format a35 head 'Component'
col dbtw format 9999999.99 head 'DBTPerMetric'
col smpcnt format 999999.99 head 'DBT Total'
col aas format 999.99 head 'AASTotal'
col aas_comp format 999.99 head 'AASPerMetric'
col bt NEW_VALUE _bt NOPRINT
col et NEW_VALUE _et NOPRINT
break on samplestart on sampleend on smpcnt on aas
alter session set nls_date_format='DD-MON-RR HH24:MI:SS';
select min(cast(sample_time as date)) bt,
max(cast(sample_time as date)) et
from v$active_session_history
where to_date(to_char(sample_time,'DD-MON-RR HH24:MI:SS'),'DD-MON-RR HH24:MI:SS')
between (sysdate-&&days_ago)
        and ((sysdate-&&days_ago)+(&&duration_min/1440));

WITH xtimes (xdate) AS
  (SELECT to_date('&_bt') xdate FROM dual
  UNION ALL
  SELECT xdate+(&&interval_mins/1440) FROM xtimes
        WHERE xdate+(&&interval_mins/1440) <= to_date('&_et')
  )
select to_char(xdate,'DD-MON-RR HH24:MI:SS') samplestart,
	nvl(sql_id,'NULL') sql_id,
       (sum(decode(event,null,0,dbtw)) over 
		(partition by to_char(xdate,'DD-MON-RR HH24:MI:SS'))) smpcnt,
       (sum(decode(event,null,0,dbtw)) over 
		(partition by to_char(xdate,'DD-MON-RR HH24:MI:SS')))/60/&&interval_mins aas,
       nvl(event,'*** IDLE *** ') tc,
       decode(event,null,0,dbtw) dbtw,
       decode(event,null,0,dbtw)/60/&&interval_mins aas_comp
from (
        select s1.xdate,event,count(*) dbtw,sql_id,count(ash.smpcnt) smpcnt
          from (
		select 	sample_id,
			sample_time,
			session_state,sql_id,
			decode(session_state,'ON CPU','CPU + CPU Wait',event) event,
			(count(sample_id) over (partition by sample_id)) smpcnt
		from v$active_session_history
		where to_date(to_char(sample_time,'DD-MON-RR HH24:MI:SS'),'DD-MON-RR HH24:MI:SS')
 			between to_date('&_bt') and to_date('&_et'))  ash,
		(select xdate from xtimes ) s1
	where 1=1 
	and ash.sample_time(+) between s1.xdate and s1.xdate+(&&interval_mins/1440)
	group by s1.xdate,event,sql_id)
order by 1,dbtw desc
/
undefine btime
undefine etime
undefine bt
undefine et
undefine interval_mins
