REM Name:    lst14-12-exawait-awr.sql
REM Purpose: Display Exadata wait information for from AWR
REM Usage:   @lst14-12-exawait-awr.sql
set pages 80
set lines 120
col event_name format a45 head 'Event'
col snaptime format  a20 head 'BeginTime'
col wtdelta format 99999999 head 'Waits'
col todelta format 99999999 head 'Timeouts'
col twdelta format 99999999 head 'SecsWaited'
break on snaptime
select snaptime,event_name,wtdelta,todelta,twdelta from (
 select snap_id,snaptime,event_name,therank,
  (waits-lag(waits,1,0) 
		over (partition by event_name order by snap_id)) wtdelta,
  (timeouts-lag(timeouts,1,0) 
		over (partition by event_name order by snap_id)) todelta,
  (time_waited-lag(time_waited,1,0) 
		over (partition by event_name order by snap_id)) twdelta
 from (
   select s.snap_id,
	  to_char(s.begin_interval_time,'DD-MON-RR HH24:MI') snaptime,
          event_name, sum(e.total_waits) waits,
          sum(e.total_timeouts) timeouts, 
	  sum(e.time_waited_micro)/1000000 time_waited,
          (rank() over (order by s.snap_id)) therank
   from dba_hist_system_event e,
        dba_hist_snapshot  s
   where s.snap_id = e.snap_id
   and s.snap_id between (&&snap_low-1) and &&snap_hi
   and s.dbid           =e.dbid
   and s.instance_number=e.instance_number
   and e.event_name like 'cell%'
   group by s.snap_id,
	to_char(s.begin_interval_time,'DD-MON-RR HH24:MI'),event_name
)
order by snap_id, twdelta desc)
where therank>1
/
undefine snap_low 
undefine snap_hi
