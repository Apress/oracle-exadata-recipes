REM Name: lst14-01-sqlmon-sqlid-text.sql
REM Purpose: Display SQL Monitor report for given SQL_ID
REM Usage: @lst14-01-sqlmon-sqlid-text.sql

set pagesize 0 echo on timing off 
set linesize 1000 trimspool on trim on 
set long 2000000 longchunksize 2000000
set echo on
spool output.text
select dbms_sqltune.report_sql_monitor( sql_id=>'&&p_sqlid',
event_detail=>'YES',
report_level=>'ALL')
from dual;
spool off

