REM Name: 	lst02-01-dbfiles.sql
REM Purpose:  	Displays tablespace file locations
REM Usage: 	From DB Instance, SQL> @lst02-01-dbfiles.sql

col type format a15 head 'File Type'
col asm_dg format a32 head 'ASM Diskgroup path'
col cnt format 9999 head 'Number of files'
set lines 80
set echo on
select 'Data Files' type,
	substr(name,1,instr(name,'/',1,2)-1) asm_dg,
	count(*) cnt
from 	v$datafile
group by substr(name,1,instr(name,'/',1,2)-1)
union
select 'Temp Files',
	substr(name,1,instr(name,'/',1,2)-1) asm_dg, 
	count(*) cnt
from v$tempfile
group by substr(name,1,instr(name,'/',1,2)-1)
union
select 'Redo Member',
	substr(member,1,instr(member,'/',1,2)-1) asm_dg, 
	count(*) cnt
from v$logfile
group by substr(member,1,instr(member,'/',1,2)-1)
/

