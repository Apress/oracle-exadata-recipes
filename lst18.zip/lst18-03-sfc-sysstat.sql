REM Name:    lst18-03-sfc-sysstat.sql
REM Purpose: Reports SFC stats for your instance
REM Usage:   SQL> @lst18-03-sfc-sysstat.sql
set lines 120
col instance_name format a10 head 'Instance'
col name format a40 head 'Statistic'
col value format 999999999999 head 'Value'
col stat format a20
set echo on
select i.instance_name,
       ss.name, ss.value 
from   gv$sysstat ss,
       gv$instance i
where  i.inst_id=ss.inst_id
and    ss.name in ('cell flash cache read hits',
            'physical read total bytes', 
	    'physical read total bytes optimized',
	    'physical read total IO requests',
	    'physical read requests optimized')
order by 2,1 asc
/
undefine sid
