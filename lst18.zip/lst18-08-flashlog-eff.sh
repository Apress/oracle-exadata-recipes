#!/bin/sh 
# Name:    lst18-08-flashlog-eff.sh
# Purpose: Show Smart Flash Logging effiency
# Usage:   ./lst18-08-flashlog-eff.sh
# Adjust the following to suit your needs
CELLGROUP=/home/oracle/cell_group
disktot=0
flashtot=0
realout=0
prevout=0
CELLCMD="dcli -g ${CELLGROUP} cellcli -e list metriccurrent "
########################################
for diskfirst in `${CELLCMD} FL_DISK_FIRST|awk '{print $4}'|sed 's/,//g'`
do
 disktot=`echo "scale=2; $disktot + $diskfirst"|bc`
done
for flashfirst in `${CELLCMD} FL_FLASH_FIRST|awk '{print $4}'|sed 's/,//g'`
do
 flashtot=`echo "scale=2; $flashtot + $flashfirst"|bc`
done
for outl in `${CELLCMD} FL_ACTUAL_OUTLIERS|awk '{print $4}'|sed 's/,//g'`
do
 realout=`echo "scale=2; $realout + $outl"|bc`
done 
for outl in `${CELLCMD} FL_PREVENTED_OUTLIERS|awk '{print $4}'|sed 's/,//g'`
do
 prevout=`echo "scale=2; $prevout + $outl"|bc`
done 
flashpct=`echo "scale=2; 100*($flashtot / ($disktot+$flashtot))"|bc`
echo "$diskfirst redo writes satisfied to Disk first"
echo "$flashfirst redo writes satisfied to Flash first"
echo "$flashpct% satisfied in Flash first"
echo "Prevented outliers: $prevout"
echo "Actual outliers: $realout"

