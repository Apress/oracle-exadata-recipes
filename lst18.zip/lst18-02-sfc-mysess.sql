REM Name:    lst18-02-sfc-mysess.sql
REM Purpose: Reports SFC information for your session
REM Usage:   SQL> @lst18-02-sfc-mysess.sql
set lines 120
col instance_name format a10 head 'Instance'
col name format a40 head 'Statistic'
col value format 999999999999 head 'Value'
col stat format a20
set echo on
select stat.name,
       sess.value value
from   v$mystat sess,
       v$statname stat
where  stat.statistic# = sess.statistic#
and    stat.name in ('cell flash cache read hits','physical read total bytes', 
            'physical reads','consistent gets','db block gets',
	    'physical read IO requests','session logical reads')
order by 1
/
undefine sid
