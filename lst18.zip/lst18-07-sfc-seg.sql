REM Name: 	lst18-07-sfc-seg.sql
REM Purpose: 	Retrieve SFC-related segment statistcis
REM Usage: 	From DB Instance, SQL> @lst18-07-sfc-seg.sql

set lines 120
col  btime format a15 head 'SnapTime'
col owner format a10 head 'Owner'
col object_name format a30 head 'Object'
col prd format 999999999 head 'PhysReads'
col oprd format 999999999 head 'OptPhysReads'
col pct format 990.90 head '%FlashReads'
prompt Current segment statistics
set echo on
select obj.owner, obj.object_name,
       segstat.pr prd, segstat.opr oprd, 
       100*(segstat.opr/segstat.pr) pct
from 
 (select * from 
  (select obj#,dataobj#,statistic_name,value
   from v$segstat) pivot
     (sum(value) for (statistic_name) in 
       ('optimized physical reads' as opr,
       'physical reads' as pr))) segstat,
  (select owner,object_name,object_id,data_object_id
   from dba_objects
   where owner=upper('&&owner') and object_name=upper('&&object_name')) obj
where segstat.obj#=obj.object_id
and segstat.dataobj#=obj.data_object_id;
set echo off
prompt Historical segment statistics from AWR
select btime,owner,object_name,
	(prtotal-lag(prtotal,1,0) over (order by snap_id)) prd,
 	(oprtotal-lag(oprtotal,1,0) over (order by snap_id)) oprd,
	100*((oprtotal-lag(oprtotal,1,0) over (order by snap_id)) / 
         (prtotal-lag(prtotal,1,0) over (order by snap_id))) pct
from (
 select   to_char(s.begin_interval_time,'DD-MON-RR HH24:MI') btime,
	  obj.owner, obj.object_name, s.snap_id,
          sum(ss.physical_reads_total) prtotal, 
	  sum(ss.optimized_physical_reads_total) oprtotal
 from   dba_objects obj,
       	dba_hist_snapshot s,
       	dba_hist_seg_stat ss,
	v$database db
 where  s.snap_id=ss.snap_id
 and 	s.dbid=ss.dbid
 and 	s.dbid=db.dbid
 and 	obj.data_object_id=ss.dataobj#
 and    obj.object_id=ss.obj#
 and 	obj.owner=upper('&&owner')
 and	obj.object_name=upper('&&object_name')
 group by to_char(s.begin_interval_time,'DD-MON-RR HH24:MI'),
	s.snap_id, obj.owner, obj.object_name
 order by 1)
;

undefine owner
undefine object_name
