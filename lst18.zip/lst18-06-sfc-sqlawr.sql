REM Name: 	lst18-06-sfc-sqlawr.sql
REM Purpose: 	Retrieve SFC-related IO request data from AWR
REM Usage: 	From DB Instance, SQL> @lst18-06-sfc-sqlawr.sql

set lines 200
col sql_id format a13
col prr format 999999999 head 'PhysReads'
col oprr format 999999999 head 'OptPhysReads'
col orate format 999.90 head 'Flash%'
set echo on
select sql_id,prr,oprr,100*(oprr/prr) orate from (
 select sql_id,sum(physical_read_requests_total) prr,
       sum(optimized_physical_reads_total) oprr
 from dba_hist_sqlstat
 where physical_read_requests_total is not null 
 group by sql_Id
 order by 2 desc)
where rownum < &&num_rows + 1 ;
undefine num_rows
