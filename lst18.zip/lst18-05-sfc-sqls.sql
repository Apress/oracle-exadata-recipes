REM Name: 	lst18-05-sfc-sqls.sql
REM Purpose: 	Retrieve SFC-related IO request data for optimized read
REM Usage: 	From DB Instance, SQL> @lst18-05-sfc-sqls.sql

set lines 200
col sql_id format a13
col prr format 999999999 head 'PhysReads'
col oprr format 999999999 head 'OptPhysReads'
col sql_text format a40 head 'SQL'
col orate format 999.90 head 'Flash%'
set echo on
select sql_Id,prr,oprr,100*(oprr/prr) orate,sql_text from (
 select sql_id,sum(physical_read_requests) prr,
       sum(optimized_phy_read_requests) oprr,
 substr(sql_text,1,40) sql_text
 from gv$sql
 where upper(sql_text) like '%MYOBJ_UNCOMP%'
 group by sql_Id,sql_text
 order by 2 desc)
where rownum < &&num_rows + 1 ;
undefine num_rows
