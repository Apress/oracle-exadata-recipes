#!/usr/bin/perl 
# Name:   lst18-01-sfcconsumer.pl
# Usage: ./lst18-01-sfcconsumer.pl [-g|-c] [cell group file|list of cells] -n [topN]

use Getopt::Std;
use Text::ParseWords;

sub usage {
 print "Usage: /lst18-01-sfcconsumer.pl [-g|-c] [cell group file|list of cells] -n [topN]\n";
}
## Command line argument handling     ##
getopts("g:c:n:",\%options);
die usage unless (defined $options{n});
die usage unless ((defined $options{c}) || (defined $options{g}));  
$dclipref="-g $options{g}" if defined $options{g};
$dclipref="-c $options{c}" if defined $options{c};
$dclitail="attributes cachedSize,dbUniqueName,hitCount,missCount,objectNumber";
## End Command line argument handling ##

open(F,"dcli ${dclipref} cellcli -e list flashcache attributes name,size|");
while (<F>) {
 @words=quotewords('\\s+', 0, $_);
 $words[2]=~s/G//; $cbytes=1024*1024*1024*$words[2];
 $cell{$words[0]}+=$cbytes;
}
close(F);
open(F,"dcli ${dclipref} cellcli -e list flashcachecontent ${dclitail}|");
while (<F>) {
 @words=quotewords('\\s+', 0, $_);
 $cached{$words[0]}+=$words[1];  # Array for storage by cell
 $db{$words[2]}+=$words[1];      # Array for storage by DB
 $mb=$words[1]/1024/1024; 
 $objd=sprintf "%-8.2f %8s %8.0f %8.0f %8.0f", "$mb", "$words[2]", "$words[3]", "$words[4]", "$words[5]"; # Bld string
 push @DTL, $objd;
}
close(F);
$tcellused=0;
$rc=0;
printf "%-10s %8s %8s %8s\n", "Cell", "Avail", "Used", "%Used";
printf "%-10s %-8s %-8s %8s\n", "-"x10, "-"x8, "-"x8, "-"x5;
foreach my $key (sort keys %cell) {
 $celltot=$cell{$key}/1024/1024/1024;
 $cellused=$cached{$key}/1024/1024/1024;
 $tcellused=$tcellused + $cellused;
 $pctused=100 * ($cellused / $celltot);
 printf "%10s %8.2f %8.2f %8.3f\n", "$key", $celltot, $cellused,$pctused;
}
printf "\n%20s %-8.2f\n\n", "Total GB used:", $tcellused;
printf "%-10s %8s %8s\n", "DB",  "DBUsed", "%Used";
printf "%-10s %8s %8s\n", "-"x10, ,"-"x8, "-"x6;
foreach my $key (sort keys %db) {
 $dbused=$db{$key}/1024/1024/1024;
 $pctused=100 * ($dbused / $tcellused);
 printf "%-10s %8.2f %8.3f\n", "$key",  $dbused,$pctused;
}
printf "\n%-8s %8s %8s %8s %8s\n", "CachedMB",  "DB", "HitCount", "MissCnt", "objNo";
printf "%-8s %8s %8s %8s %8s\n", "-"x8, "-"x8, "-"x8, "-"x8, "-"x8;
foreach my $line (sort { $b <=> $a } @DTL) {
 last if $rc eq $options{n};
 print "$line\n";
 $rc++;
}
