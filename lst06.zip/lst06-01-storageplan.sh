#!/bin/sh
# Name: 	lst06-01-storageplan.sh
# Purpose: 	Calculates usable storage based on input criteria
# Usage: 	./lst06-01-storageplan.sh

# raw storage variables
export q_raw_hp=21.6
export h_raw_hp=50.4
export f_raw_hp=100.8
export q_raw_hc=108
export h_raw_hc=252
export f_raw_hc=504

failme() {
  echo "Invalid choice" && exit 1
}

choose_config() {
echo "Choose Exadata Configuration"
echo "1. Quarter Rack High Performance"
echo "2. Quarter Rack High Capacity"
echo "3. Half Rack High Performance"
echo "4. Half Rack High Capacity"
echo "5. Full Rack High Performance"
echo "6. Full Rack High Capacity"
read config
case $config in 
1) export raw_sz=$q_raw_hp;;
2) export raw_sz=$q_raw_hc;;
3) export raw_sz=$h_raw_hp;;
4) export raw_sz=$h_raw_hc;;
5) export raw_sz=$f_raw_hp;;
6) export raw_sz=$f_raw_hc;;
*) failme
esac
}

choose_reco_pct() {
 echo "Enter % allocation for RECO storage (i.e., 40 = 40%): \c"
 read recopct
 recopct=`echo "scale=4; $recopct/100"| bc`
 datapct=$(echo "1 - $recopct"| bc)
 export reco_raw_sz=$(echo "$raw_sz * $recopct"| bc)
 export data_raw_sz=$(echo "$raw_sz * $datapct"| bc)
}

choose_asm() {
echo "Choose ASM Configuration"
echo "1. Data: Normal, Reco: Normal"
echo "2. Data: Normal, Reco: High"
echo "3. Data: High,   Reco: High"
echo "4. Data: High,   Reco: Normal"
read asmpick
case $asmpick in
1) dc=`echo "scale=2; $data_raw_sz/2"| bc`
   rc=`echo "scale=2; $reco_raw_sz/2"| bc` ;;
2) dc=`echo "scale=2; $data_raw_sz/2"| bc`
   rc=`echo "scale=2; $reco_raw_sz/3"| bc` ;;
3) dc=`echo "scale=2; $data_raw_sz/3"| bc`
   rc=`echo "scale=2; $reco_raw_sz/3"| bc` ;;
4) dc=`echo "scale=2; $data_raw_sz/3"| bc`
   rc=`echo "scale=2; $reco_raw_sz/2"| bc` ;;
*) failme
esac
}

choose_config
choose_reco_pct
choose_asm

echo "Exadata Storage Sizing Details"
echo "=============================="
echo "Initial raw capacity is $raw_sz\n"
echo "Final DATA usable capacity is $dc TB\n"
echo "Final RECO usable capacity is $rc TB\n"



