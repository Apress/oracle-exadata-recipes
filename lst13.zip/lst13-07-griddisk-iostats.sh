#!/bin/sh 
# Name: lst13-07-griddisk-iostats.sh
# Purpose: Show current grid disk metrics 
# Usage: ./lst13-07-griddisk-iostats.sh [metriccurrent|metrichistory]

SCOPE=$1		# run with either metriccurrent or metrichistory

# Adjust the following to suit your needs
CELLGROUP=/home/oracle/cell_group
MBMIN=1		        ## 1 MB/second per disk
IORQMIN=10		## 10 IOPs per disk
LATMIN=10000		## 10 ms latency
########################################

## Metrics list per type #####################################################
MBPS="GD_IO_BY_R_LG_SEC GD_IO_BY_R_SM_SEC GD_IO_BY_W_LG_SEC GD_IO_BY_W_SM_SEC"
IORQ="GD_IO_RQ_R_LG_SEC GD_IO_RQ_R_SM_SEC GD_IO_RQ_W_LG_SEC GD_IO_RQ_W_SM_SEC"
LAT="GD_IO_TM_R_LG_RQ GD_IO_TM_R_SM_RQ GD_IO_TM_W_LG_RQ GD_IO_TM_W_SM_RQ"
##############################################################################

# dcli/cellcli commands
for met in $MBPS
do
echo "Listing ${SCOPE} for ${met} when IO rate > ${MBMIN} MB/second"
dcli -g ${CELLGROUP} "cellcli -e list ${SCOPE} \
	where objectType=\'GRIDDISK\' and name=\'${met}\' \
	and metricValue \> ${MBMIN}"
done
for met in $IORQ
do
echo "Listing ${SCOPE} for ${met} when #requests > ${IORQMIN} IO requests/second"
dcli -g ${CELLGROUP} "cellcli -e list ${SCOPE} \
	where objectType=\'GRIDDISK\' and name=\'${met}\' \
	and metricValue \> ${IORQMIN}"
done
for met in $LAT
do
echo "Listing ${SCOPE} for ${met} when IO latency > ${LATMIN} microseconds"
dcli -g ${CELLGROUP} "cellcli -e list ${SCOPE} \
	where objectType=\'GRIDDISK\' and name=\'${met}\' \
	and metricValue \> ${LATMIN}"
done

