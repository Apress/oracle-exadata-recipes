#!/usr/bin/perl 
# Name: lst13-01-activereq.pl
# Usage: ./lst13-01-ar.pl [-g|-c] [cell group file|list of cells] [-s|-v]

use Getopt::Std;
use Text::ParseWords;

sub usage {
 print "Usage: ./lst13-01-ar.pl [-g|-c] [cell group file|list of cells] [-s|-v]\n";
}
sub prtheader {
printf "%-90s\n","-"x90;
}

sub prtreport {
 my $header=$_[1];
 print "\n$header\n";&prtheader;
 my(%currarray) = %{$_[0]};
 foreach my $key (sort keys %currarray) {
  printf "%10s %-8.0f\n", "$key", "$currarray{$key}";
 }
}
## Command line argument handling     ##
getopts("svg:c:",\%options);
die usage unless ((defined $options{s}) || (defined $options{v}));  
die usage unless ((defined $options{c}) || (defined $options{g}));  
$dclipref="-g $options{g}" if defined $options{g};
$dclipref="-c $options{c}" if defined $options{c};
$dclitail="attributes dbName,ioReason,ioType,ioBytes, requestState" if defined $options{s};
$dclitail="attributes dbName,ioReason,ioType,ioBytes,requestState,sqlID,sessionID,objectNumber" if defined $options{v};
## End Command line argument handling ##

open(F,"dcli ${dclipref} cellcli -e list activerequest ${dclitail}|");
while (<F>) {
 @words= quotewords('\\s+', 0, $_);
  $ars++;                       # Total active requests
  $ars++;                       # Total active requests
  ## Build various arrays to store cellcli output ##
  unless (/Heartbeat/) {
  if (/PredicateCacheGet/) {
      $cell{$words[0]}++;                            # cell name
      $dbnm{$words[1]}++;                            # db name
      $as=sprintf "%-10s %-18s %-25s %-30s", "$words[1]","Null","$words[2]","$words[4]";  
      $asqlid=sprintf "%-10s %-15s", "$words[1]", "$words[5]";
      $aobj=sprintf "%-10s %-15s", "$words[1]", "$words[7]";
      $bytesperop{$as}+=$words[3]/1048576;
      $cntperop{$as}++;
      $bytespersql{$asqlid}+=$words[3]/1048576;
      $cntpersql{$asqlid}++;
      $bytesperobj{$aobj}+=$words[3]/1048576;
      $cntperobj{$aobj}++;
      $tbytes+=$words[3];
  } else {
      $cell{$words[0]}++;                           
      $dbnm{$words[1]}++;                          
      $as=sprintf "%-10s %-18s %-25s %-30s", "$words[1]","$words[2]","$words[3]","$words[5]"; 
      $asqlid=sprintf "%-10s %-15s", "$words[1]", "$words[6]";
      $aobj=sprintf "%-10s %-15s", "$words[1]", "$words[8]";
      $bytesperop{$as}+=$words[4]/1048576;                      
      $cntperop{$as}++;                             
      $bytespersql{$asqlid}+=$words[4]/1048576;
      $cntpersql{$asqlid}++;
      $bytesperobj{$aobj}+=$words[4]/1048576;
      $cntperobj{$aobj}++;
      $tbytes+=$words[4];
  }}
  ## End various arrays to store cellcli output ##
}
## Print output ##
if ($ars > 0) {
 $hdr=sprintf "%-10s %-10s", "Cell", "#Requests"; &prtreport(\%cell, $hdr);
 $hdr=sprintf "%-10s %-10s", "DB", "#Requests";   &prtreport(\%dbnm, $hdr);
 $hdr=sprintf "%-10s %-18s %-25s %-30s %-10s", "DB", "ioReason", "ioType", "requestState", "MB"; &prtreport(\%bytesperop, $hdr);
 $hdr=sprintf "%-10s %-18s %-25s %-30s %-10s", "DB", "ioReason", "ioType", "requestState", "#Requests"; &prtreport(\%cntperop, $hdr);
 if (defined $options{v}) {
   $hdr=sprintf "%-10s %-15s %-10s", "DB", "SqlID", "MB"; &prtreport(\%bytespersql, $hdr);
   $hdr=sprintf "%-10s %-15s %-10s", "DB", "SqlID", "#Requests"; &prtreport(\%cntpersql, $hdr);
   $hdr=sprintf "%-10s %-15s %-10s", "DB", "Object", "MB"; &prtreport(\%bytesperobj, $hdr);
   $hdr=sprintf "%-10s %-15s %-10s", "DB", "Object", "#Requests"; &prtreport(\%cntperobj, $hdr);
 }
}
## End Print output ##

