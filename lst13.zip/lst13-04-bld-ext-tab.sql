REM:  Name: lst13-04-bld-ext-tab.sql
REM:  Purpose: Build external table from metrichistory data
REM:  Usage: lst13-04-bld-ext-tab.sql

create table celliorm.db_metrics_ext
 (cell_server varchar2(100),
  metric_name varchar2(100),
  metric_dtl  varchar2(256),
  dtl_value   number,
  dtl_unit    varchar2(36),
  sample_time varchar2(256))
 organization external
 (type oracle_loader
 default directory my_dir
  access parameters
 (records delimited by newline
 fields terminated by whitespace)
 location ('db_io_laod.dat')
 ) reject limit 100000000
/
