#!/bin/sh
# Name: lst13-02-metricsum.sh
# Usage: ./lst13-02-metricsum.sh [-c|-g] [cell|cell_group] -m [metric]

export rscript=./lst13-03-metricsum.r

usage() {
 echo "Usage: `basename $0` [-c|-g] [cell|cell_group] -m [metric]"
 echo "Invalid metric: $1"
 exit 1 
}

case $# in
4)
  if [ "$1" == "-c" ] && [ "$3" == "-m" ]; then
     scp=$1; cells=$2; metric=$4
     export a4=$4
  elif [ "$1" == "-g" ] && [ "$3" == "-m" ]; then
     scp=$1; cells=$2; metric=$4
  else 
	usage
  fi
  metricdesc=`dcli ${scp} ${cells} cellcli -e list metricdefinition ${metric} \
	attributes description|head -1 | awk 'BEGIN { FS = "\"" } ; { print $2 }'`
  unit=`dcli ${scp} ${cells} cellcli -e list metricdefinition ${metric} \
	attributes unit|head -1 | sed 's/IO requests/IORequests/g'| \
          awk '{ print $2 }'`
  if [ -z "${metricdesc}" ]; then 
    usage ${metric}
  fi
  case $metric in 
  CD*|GD*) plt=1;;
  *) plt=2;;
  esac
  echo "Reporting on ${metric}: ${metricdesc}"
  echo "This could take awhile ..."
  dcli --serial ${scp} ${cells} cellcli -e list metrichistory ${metric}  attributes name,metricObjectName,metricValue,collectionTime |  sed 's/,//g' | sed 's/IO requests/IORequests/g'  |  ${rscript} ${metric} ${unit} ${plt}
  ;;
*)
   usage;;
esac
