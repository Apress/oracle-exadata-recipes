#!/bin/sh 
# Name: lst13-08-interconnect-probs.sh
# Purpose: Show host interconnect metrics above threshold
# Usage: ./lst13-08-interconnect-probs.sh [metriccurrent|metrichistory]

SCOPE=$1		# run with either metriccurrent or metrichistory

# Adjust the following to suit your needs
CELLGROUP=/home/oracle/cell_group
MBMIN=0		## 0 MB/second for each type of dtop
########################################

## Metrics list per type #####################################################
MBPS="N_MB_DROP_SEC N_MB_RDMA_DROP_SEC N_MB_RESENT_SEC"
##############################################################################

# dcli/cellcli commands
for met in $MBPS
do
echo "Listing ${SCOPE} for ${met} when IO rate > ${MBMIN} MB/second"
dcli -g ${CELLGROUP} "cellcli -e list ${SCOPE} \
	where objectType=\'HOST_INTERCONNECT\' and name=\'${met}\' \
	and metricValue \> ${MBMIN}"
done
