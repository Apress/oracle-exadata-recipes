#!/usr/bin/perl 
# Name: lst13-06-celldisk-smallvslarge.pl
# Usage: ./lst13-06-celldisk-smallvslarge.pl [--g|--c]=[cell group file|list of cells]
use Getopt::Long;
use Text::ParseWords;
sub usage {
 print "Usage: ./lst13-07-celldisk-smallvslarge.pl [--g|--c]=[cell group file|list of cells]\n";
}
## Command line argument handling     ##
GetOptions(
  'cell=s' => \$c,
  'grp=s' => \$g,
) or die usage;
die usage unless defined($g) || defined ($c);
$dclipref="-g $g" if defined($g);
$dclipref="-c $c" if defined($c);
## End Command line argument handling ##
foreach $metric ("CD_IO_RQ_R_SM","CD_IO_RQ_R_LG") { 	
 open(F,"dcli ${dclipref} \"cellcli -e list metriccurrent where name like \'${metric}\'\"|");
 while (<F>) {
  @words=quotewords('\\s+', 0, $_);
  $words[3]=~ s/,//g;
  $iot{total} += $words[3];
  $ios{HardDisk} += $words[3] if ($words[2]=~ /^CD/) && ($metric=~/SM/);  # assumes hard disks start with CD
  $ios{FlashDisk} += $words[3] if ($words[2]=~ /^FD/) && ($metric=~/SM/); # assumes flash disks start with FD
  $iol{HardDisk} += $words[3]  if ($words[2]=~ /^CD/) && ($metric=~/LG/);  # assumes hard disks start with CD
  $iol{FlashDisk} += $words[3] if ($words[2]=~ /^FD/) && ($metric=~/LG/); # assumes flash disks start with FD
 }
 close(F);
} 
printf "%-40s=%8.0f\n", "Small IO Requests for Hard Disks", $ios{HardDisk};
printf "%-40s=%8.0f\n", "Small IO Requests for Flash Disks", $ios{FlashDisk};
printf "%-40s=%8.0f\n", "Large IO Requests for Hard Disks", $iol{HardDisk};
printf "%-40s=%8.0f\n", "Large IO Requests for Flash Disks", $iol{FlashDisk};
printf "%-40s=%8.2f%\n", "% of Large IO Requests for Hard Disks", 100*($iol{HardDisk}/($iol{HardDisk} + $ios{HardDisk}));
printf "%-40s=%8.2f%\n", "% of Large IO Requests for All Disks", 100*(($iol{HardDisk}+$iol{FlashDisk})/$iot{total});
