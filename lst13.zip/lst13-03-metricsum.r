#!/usr/bin/env Rscript
# Name:  lst13-03-metricsum.r
# Usage: (output) | ./lst13-03-metricsum.r [metric] [unit] [1|2}

msg.trap <- capture.output(suppressMessages(library("ggplot2")))
msg.trap <- capture.output(suppressMessages(library("RColorBrewer")))

args <- commandArgs(trailingOnly = TRUE)	   
local.plt    <- c(as.numeric(args[3]));
local.title  <- paste(args[1],"in",args[2])
fn.line <- args[1]
fn.hist <- paste(fn.line,"_FREQ",sep="")
df <- read.table("stdin")  # main df frame     
colnames(df) <- c('cell','metric', 'metricObjectName','metricValue','myx','collectionTime') 
cat("Cell Summary information\n")
by(df[,c('metricValue')],df$cell,summary)      
cat("\n\nMetric Object Summary information\n")
by(df[,c('metricValue')],df$metricObjectName, summary)  
if (local.plt == 1) {
 pline <- ggplot(df,aes(collectionTime,metricValue,colour=cell))
 pline <- pline + geom_line(aes(colour=cell,group=1))
 pline <- pline + facet_grid(cell ~ .) 
 pline <- pline + opts(title=local.title)
 phist <- ggplot(df, aes(metricValue, fill=cell)) + geom_bar(binwidth=5) 
 phist <- phist + facet_grid(cell ~ .) 
 phist <- phist + opts(title=local.title)
 } else {
 pline <- ggplot(df,aes(collectionTime,metricValue,colour=metricObjectName))
 pline <- pline + geom_line(aes(colour=metricObjectName,group=1))
 pline <- pline + facet_grid(metricObjectName ~ .) 
 pline <- pline + opts(title=local.title)
 phist <- ggplot(df, aes(metricValue, fill=metricObjectName)) + geom_bar(binwidth=5) 
 phist <- phist + facet_grid(metricObjectName ~ .) 
 phist <- phist + opts(title=local.title)
}
pdf(paste(fn.line,".pdf",sep=""))             
print(pline)
pdf(paste(fn.hist,".pdf",sep=""))             
print(phist)
