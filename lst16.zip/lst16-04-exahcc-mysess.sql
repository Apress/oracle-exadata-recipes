REM Name:    lst16-04-exahcc-mysess.sql
REM Purpose: Display smart scan and compression stats for session
REM Usage: SQL> @lst16-04-exahcc-mysess.sql

set lines 200
col instance_name format a10 head 'Instance'
col name format a70 head 'Statistic'
col value format 999,999,999,999,999 head 'Value'
col stat format a20
set echo on
select stat.name,
       sess.value value
from   v$mystat sess,
       v$statname stat
where  stat.statistic# = sess.statistic#
and    stat.name in ('physical read total bytes',
	 'CPU used by this session',
	 'cell CUs sent uncompressed',
	 'cell IO uncompressed bytes',
 	 'cell physical IO interconnect bytes')
and sess.value > 0
order by 1
/
undefine sid
