REM Name:    lst16-09-getrowidinfo.sql
REM Purpose: Get rowid info
REM Usage: SQL> @lst16-09-getrowidinfo.sql
set lines 200
col object_name format a20 head "ObjectName"
col rowid format a23 head "RowID"
col fno format 999 head "File#"
col blk format 9999999 head "Blk#"
set echo on
select object_name,rowid,
       dbms_rowid.rowid_to_absolute_fno(rowid,'D14','MYOBJ_XX') fno,
       dbms_rowid.rowid_block_number(rowid,'BIGFILE') blk
from d14.myobj_xx
where object_name='SOURCE$'
/
