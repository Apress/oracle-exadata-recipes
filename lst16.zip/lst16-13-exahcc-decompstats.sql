REM Name:    lst16-13-exahcc-decompstats.sql
REM Purpose: Display I/O and compression stats for session
REM Usage: SQL> @lst16-13-exahcc-decompstats.sql

set lines 200
col instance_name format a10 head 'Instance'
col name format a70 head 'Statistic'
col value format 999999999999999 head 'Value'
col stat format a20
set echo on
select stat.name,
       sess.value value
from   v$mystat sess,
       v$statname stat
where  stat.statistic# = sess.statistic#
and    stat.name in ('physical read total bytes',
	 'CPU used by this session',
	 'EHCC CUs Decompressed',
	 'EHCC Query High CUs Decompressed',
	 'EHCC Query Low CUs Decompressed',
	 'EHCC Archive CUs Decompressed',
	 'cell CUs sent uncompressed',
	 'cell CUs processed for uncompressed',
	 'cell physical IO bytes eligible for predicate offload',
	 'cell IO uncompressed bytes',
 	 'cell physical IO interconnect bytes')
and sess.value > 0
order by 1
/
undefine sid
