REM Name:    lst16-05-exahcc-sqls.sql
REM Purpose: Display HCC stats for queries
REM Usage:   SQL> @lst16-05-exahcc-sqls.sql
set lines 200
col sql_id format a13 head 'SqlID'
col avgelapsed format 999,999,999.00 head 'AvgElaspedSecs'
col sql_text format a30 head 'SQL'
col phymb format 999,999,999 head "PhysIOMb"
col celluncompmb format 999,999,999 head "CellUncompMB"
col icmb format 999,999,999 head "InterconnectMB"

set echo on
select  sql_id ,avgelapsed,phybytes/1024/1024 phymb,
	io_cell_uncompressed_bytes/1024/1024 celluncompmb,
 	io_interconnect_bytes/1024/1024 icmb,
         sql_text
from (
 select  sql_id,
        physical_read_bytes+physical_write_bytes phybytes,io_interconnect_bytes,
	(elapsed_time/1000000)/
        executions/
         decode(px_servers_executions,0,1,px_servers_executions) avgelapsed,
       substr(sql_text,1,30) sql_text,
       io_cell_uncompressed_bytes
 from v$sql
 where executions > 0
 and sql_text like '%'||'&&sql_text'||'%'
 order by avgelapsed desc)
;
undefine sql_text
