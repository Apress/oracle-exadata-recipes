REM Name:    lst16-12-hcclocks.sql
REM Purpose: Reports lock holder information 
REM Usage:   SQL> @lst16-12-hcclocks.sql
set lines 200
set echo on
select row_wait_block#,row_wait_row#,
blocking_instance,blocking_session
from v$session 
where sid='&&waiting_sid'
/
undefine waiting_sid
