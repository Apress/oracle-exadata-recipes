REM Name: lst16-01-compadv.sql
REM Purpose: Runs dbms_compression.get_compression_ratio for a table
REM Usage: SQL> @lst16-01-compadv.sql

set serveroutput on size 20000
set echo on
declare
 l_blkcnt_cmp 	binary_integer;
 l_blkcnt_uncmp binary_integer;
 l_row_cmp 	binary_integer;
 l_row_uncmp	binary_integer;
 l_cmp_ratio 	number;
 l_comptype_str varchar2(200);
begin
 dbms_compression.get_compression_ratio(scratchtbsname=>'&&tbs',
   ownname=>upper('&tab_owner'),
   tabname=>upper('&table'),
   partname=>null,
   comptype=>dbms_compression.comp_for_query_low,
   blkcnt_cmp=>l_blkcnt_cmp,
   blkcnt_uncmp=>l_blkcnt_uncmp,
   row_cmp=>l_row_cmp,
   row_uncmp=>l_row_uncmp,
   cmp_ratio=>l_cmp_ratio,
   comptype_str=>l_comptype_str);
   dbms_output.put_line('Blocks, Compressed='||l_blkcnt_cmp);
   dbms_output.put_line('Blocks, Uncompressed='||l_blkcnt_uncmp);
   dbms_output.put_line('Rows, Compressed='||l_row_cmp);
   dbms_output.put_line('Rows, Uncompressed='||l_row_uncmp);
   dbms_output.put_line('Compression Ratio='||l_cmp_ratio);
   dbms_output.put_line('Compression Type='||l_comptype_str);
end;
/
undefine tbs
undefine tab_owner
undefine table
