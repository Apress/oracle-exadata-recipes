REM Name: 	lst09-05-create-diskgroup.sql
REM Purpose: 	Creates ASM Disk group
REM Usage: 	From ASM Instance as SYSASM, SQL> @lst09-05-create-diskgroup.sql
REM 	 : 	Enter an ASM 

create diskgroup SDATA_CM01
    normal redundancy
    failgroup cm01cel01
    disk        'o/192.168.10.3/SDATA_CD_00_cm01cel01,
    	      o/192.168.10.3/SDATA_CD_01_cm01cel01'
    failgroup cm01ce0l2
    disk        'o/192.168.10.4/SDATA_CD_00_cm01cel02,
    	      o/192.168.10.4/SDATA_CD_01_cm01cel02'
    attribute   'compatible.rdbms' = '11.2.0.3',
   	      'compatible.asm' = '11.2.0.3.0',
   	      'cell.smart_scan_capable' = 'TRUE',
   	      'au_size' = '4M';

