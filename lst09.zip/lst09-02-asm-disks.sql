REM Name: 	lst09-02-asm-disks.sql
REM Purpose: 	Display ASM disk group disk information
REM Usage: 	From ASM Instance as SYSASM, SQL> @lst09-02-asm-disks.sql
REM 	 : 	Enter an ASM disk group name

set lines 150
set pages 80
col path format a50
col name format a10 head 'Disk Group'
col path format a45 head 'Disk'
col state format a10 head 'State'
col failgroup format a20 head 'Failgroup'
set echo on
select a.name,b.path
from v$asm_diskgroup a, v$asm_disk b
where a.group_number=b.group_number
and (a.name='&&diskgroup_name' or '&&diskgroup_name' is null)
order by 2,1
/
undefine diskgroup_name


