REM Name: 	lst09-17-ss-enabled.sql
REM Purpose: 	Display ASM disk group cell.smart_scan_capable attribute
REM Usage: 	From ASM Instance as SYSASM, SQL> @lst09-17-ss-enabled.sql

set lines 100
col group_number format 9999 head 'Group|Number'
col name format a35 head 'ASM Attribute|Name'
col dgname format a15 head 'DiskGroup|Name'
col value format a30 head 'ASM Attribute|Value'

set echo on
select a.group_number,b.name dgname,a.name,a.value
  from v$asm_attribute a,
  v$asm_diskgroup b
  where a.name = 'cell.smart_scan_capable'
  and b.name in ('&&dg_1','&&dg_2')
  and a.group_number=b.group_number
/
undefine dg_1
undefine dg_2
