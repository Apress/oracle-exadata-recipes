REM Name: 	lst09-11-asm-extentbal-variance.sql
REM Purpose: 	Display ASM extent balance variance for disk groups
REM Usage: 	From ASM Instance as SYSASM, SQL> @lst09-11-asm-extentbal-variance.sql

set lines 180
col name format a10 head 'Disk Group'
col var1 format 999.99 head 'Disk size|variance'
col var2 format 999.99 head 'Extent imbalance|variance'
col maxtpd format 999999999 head 'Max disk|size (MB)'
col mintpd format 999999999 head 'Min disk|size (MB)'
col maxfpd format 999999999 head 'Max free|size (MB)'
col minfpd format 999999999 head 'Min free|size (MB)'
set echo on
select distinct name,
	round(100*((maxfpd-minfpd)/maxfpd),2) var2
from (
	select dg.name,
		dg.total_mb tpdg,
		dg.free_mb fpdg,
		d.total_mb tpd,
		d.free_mb fpd,
		max(d.total_mb) over (partition by dg.name) maxtpd,
		min(d.total_mb) over (partition by dg.name) mintpd,
		max(d.free_mb) over (partition by dg.name) maxfpd,
		min(d.free_mb) over (partition by dg.name) minfpd
		from v$asm_diskgroup dg, v$asm_disk d
		where dg.group_number=d.group_number
		and (dg.name='&&diskgroup_name' or '&&diskgroup_name' is null)
       )
/
undefine diskgroup_name
