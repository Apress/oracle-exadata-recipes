REM Name: 	lst09-06-create-diskgroup.sql
REM Purpose: 	Creates ASM Disk group and sets correct attributes
REM Usage: 	From ASM Instance as SYSASM, SQL> @lst09-06-create-diskgroup.sql
REM 	 : 	Enter an ASM 

create diskgroup SDATA_CM01
    normal redundancy
    disk 'o/*/SDATA*'
    attribute 'compatible.rdbms' = '11.2.0.3',
    	      'compatible.asm' = '11.2.0.3.0',
    	      'cell.smart_scan_capable' = 'TRUE',
    	      'au_size' = '4M';

