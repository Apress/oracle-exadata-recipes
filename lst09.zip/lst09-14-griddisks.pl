#!/usr/bin/perl
# Name: lst09-14-griddisks.pl
# Purpose: Show Exadata grid disk details
# Usage: ./lst09-14-griddisks.pl

open(F,"dcli -g ./cell_group cellcli -e list griddisk attributes name,size,offset|");
while (<F>) {
 $tgd++;
 ($cd,$gd,$sz,$offset)=split(' ',$_);
  $gd=substr $gd,0,index($gd,"_");
  $cell{$cd}++;
  $cell{$gd}++;
  push @CELLS, $cd ;
  push @GDS, $gd;
  push @DTL, "$gd".":\tSize "."$sz".":\tOffset ".$offset."\n";
}
print "Total grid disks: $tgd\n";
%seen = ();
@UNIQCELLS= grep { ! $seen{$_} ++ } @CELLS;
foreach (@UNIQCELLS) {
 print "$_ has $cell{$_} grid disks\n";
}
%seen = ();
@UNIQGDS= grep { ! $seen{$_} ++ } @GDS;
foreach (@UNIQGDS) {
 print "$_ is built on $cell{$_} grid disks\n";
}
%seen = ();
@UNIQDTL= grep { ! $seen{$_} ++ } @DTL;
foreach (@UNIQDTL) {
 print "Distinct size and offsets for : $_";
}


