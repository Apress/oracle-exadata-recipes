REM Name: 	lst09-03-create-diskgroup.sql
REM Purpose: 	Creates ASM Disk group
REM Usage: 	From ASM Instance as SYSASM, SQL> @lst09-03-create-diskgroup.sql
REM 	 : 	Enter an ASM 

create diskgroup MY_DG
    normal redundancy
    disk 'o/*/DATA*'
    attribute 'compatible.rdbms' = '11.2.0.3',
    	      'compatible.asm' = '11.2.0.3.0',
    	      'cell.smart_scan_capable' = 'TRUE',
    	      'au_size' = '4M';

