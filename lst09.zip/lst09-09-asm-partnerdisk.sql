REM Name: 	lst09-09-asm-partnerdisk.sql
REM Purpose: 	Display ASM disk partner information
REM Usage: 	From ASM Instance as SYSASM, SQL> @lst09-09-asm-partnerdisk.sql

set pages 1000
set lines 200
set echo on
col disk_path format a40 head 'Primary|Path'
col partner_path format a40 head 'Partner|Path'
col group_number format 999 head 'Grp'
col disk# format 999 head 'Primary|Disk'
col name format a10 head 'Disk Group'
col number_kfdpartner format 999 head 'Partner|Disk'
break on group_numner on disk_numner on disk_path
SELECT dg.name,
d.disk_number "Disk#",
d.path disk_path,
p.number_kfdpartner ,
pd.path partner_path
FROM x$kfdpartner p,
v$asm_disk d,
v$asm_disk pd,
v$asm_diskgroup dg
WHERE p.disk=d.disk_number
and p.grp=d.group_number
and p.number_kfdpartner = pd.disk_number
and p.grp=pd.group_number
and d.group_number=dg.group_number
and (dg.name='&&diskgroup_name' or '&&diskgroup_name' is null)
and (d.path like '%'||'&&disk_path'||'%' or '&&disk_path' is null)
ORDER BY 1, 2, 3
/
undefine diskgroup_name
undefine disk_path
