REM Name: 	lst09-01-asm-disk-details.sql
REM Purpose: 	Display ASM disk group details in prep for recreation	
REM Usage: 	From ASM Instance as SYSASM, SQL> @lst09-01-asm-disk-details.sql

col name format a12 head 'Disk Group'
col total_mb format 999999999 head 'Total MB|Raw'
col free_mb format 999999999 head 'Free MB|Raw'
col avail_mb format 999999999 head 'Total MB|Usable'
col usable_mb format 999999999 head 'Free MB|Usable'
col cdisks format 99999 head 'Cell|Disks'
set line 180
select a.name,a.total_mb,a.free_mb,a.type,
decode(a.type,'NORMAL',a.total_mb/2,'HIGH',a.total_mb/3) avail_mb,
decode(a.type,'NORMAL',a.free_mb/2,'HIGH',a.free_mb/3) usable_mb,
count(b.path) cdisks
from v$asm_diskgroup a, v$asm_disk b
where a.group_number=b.group_number
group by a.name,a.total_mb,a.free_mb,a.type,
decode(a.type,'NORMAL',a.total_mb/2,'HIGH',a.total_mb/3) ,
decode(a.type,'NORMAL',a.free_mb/2,'HIGH',a.free_mb/3)
order by 2,1
/

col failgroup format a10 head 'Cell'
col cnt format 999 head 'Disks per Cell'
select a.name,b.failgroup,count(*) cnt
from v$asm_diskgroup a, v$asm_disk b
where a.group_number=b.group_number
group by a.name,b.failgroup
/

col group_number format 9999 head 'Group|Number'
col name format a35 head 'ASM Attribute|Name'
col dgname format a15 head 'DiskGroup|Name'
col value format a30 head 'ASM Attribute|Value'
set pages 80
set echo on
select a.group_number,b.name dgname,a.name,a.value
  from v$asm_attribute a,
  v$asm_diskgroup b
  where a.name in ('au_size','disk_repair_time',
		'compatible.rdbms','compatible.asm')
  and a.group_number=b.group_number
  order by b.name,a.name
/
