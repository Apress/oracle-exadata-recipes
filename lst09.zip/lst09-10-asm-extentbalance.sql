REM Name: 	lst09-10-asm-extentbalance.sql
REM Purpose: 	Display ASM extent balance across disks
REM Usage: 	From ASM Instance as SYSASM, SQL> @lst09-10-asm-extentbalance.sql

set lines 180
col name format a10 head 'Disk Group'
col var1 format 999.99 head 'Disk size|variance'
col var2 format 999.99 head 'Extent imbalance|variance'
col maxtpd format 999999999 head 'Max disk|size (MB)'
col mintpd format 999999999 head 'Min disk|size (MB)'
col maxfpd format 999999999 head 'Max free|size (MB)'
col minfpd format 999999999 head 'Min free|size (MB)'
set echo on
select 	distinct name,
	maxtpd, mintpd, maxfpd, minfpd,
	round(100*((maxtpd-mintpd)/maxfpd),2) var1,
	round(100*((maxfpd-minfpd)/maxfpd),2) var2
from (
	select dg.name,
		dg.total_mb tpdg,
		dg.free_mb fpdg,
		d.total_mb tpd,
		d.free_mb fpd,
		max(d.total_mb) over (partition by dg.name) maxtpd,
		min(d.total_mb) over (partition by dg.name) mintpd,
		max(d.free_mb) over (partition by dg.name) maxfpd,
		min(d.free_mb) over (partition by dg.name) minfpd
	from v$asm_diskgroup dg, v$asm_disk d
where dg.group_number=d.group_number)
/
