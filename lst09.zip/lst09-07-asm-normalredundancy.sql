REM Name: 	lst09-07-asm-normalredundancy.sql
REM Purpose: 	Display ASM disk group details for normal redundancy disk group
REM Usage: 	From ASM Instance as SYSASM, SQL> @lst09-07-asm-normalredundancy.sql

col name format a12 head 'Disk Group'
col total_mb format 999999999 head 'Total MB|Raw'
col free_mb format 999999999 head 'Free MB|Raw'
col avail_mb format 999999999 head 'Total MB|Usable'
col usable_mb format 999999999 head 'Free MB|Usable'
col cdisks format 99999 head 'Cell|Disks'
set line 180
select a.name,a.total_mb,a.free_mb,a.type,
decode(a.type,'NORMAL',a.total_mb/2,'HIGH',a.total_mb/3) avail_mb,
decode(a.type,'NORMAL',a.free_mb/2,'HIGH',a.free_mb/3) usable_mb,
count(b.path) cdisks
from v$asm_diskgroup a, v$asm_disk b
and a.name='&&diskgroup_name'
where a.group_number=b.group_number
group by a.name,a.total_mb,a.free_mb,a.type,
decode(a.type,'NORMAL',a.total_mb/2,'HIGH',a.total_mb/3) ,
decode(a.type,'NORMAL',a.free_mb/2,'HIGH',a.free_mb/3)
order by 2,1
/

undefine diskgroup_name
