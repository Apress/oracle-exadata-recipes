REM Name:    lst19-01-exastorind-mysess.sql
REM Purpose: Display smart scan, I/O, and storage index behavior for your session
REM Usage: SQL> @lst15-03-exass-mysess.sql

set lines 200
col instance_name format a10 head 'Instance'
col name format a70 head 'Statistic'
col value format 999,999,999,999,999.90 head 'Value (MB)'
col stat format a20
set echo on
select stat.name,
       sess.value/1024/1024 value
from   v$mystat sess,
       v$statname stat
where  stat.statistic# = sess.statistic#
  and stat.name in 
   ('cell physical IO bytes eligible for predicate offload',
     'cell physical IO interconnect bytes',
     'cell physical IO bytes saved by storage index',
     'cell physical IO interconnect bytes returned by smart scan')
order by 1
/
undefine sid
