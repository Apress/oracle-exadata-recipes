#!/usr/bin/perl
# Name: lst19-07-storindsum.pl
# Usage: ./lst19-07-storindsum.pl -o [dataobj#]
# To do: do the pattern matching
use Getopt::Std;
use Text::ParseWords;
use Env;
sub usage { 
 print "Usage: /lst19-07-storindsum.pl -o [dataobj#]\n";
} 
getopts("o:",\%options);
die usage unless (defined $options{o});
$hostname=$ENV{HOSTNAME};
$hostname=~s/\..*//;
$trcdir="/var/log/oracle/diag/asm/cell/$hostname/trace";
$p=0;
open(F,"cat $trcdir/svtrc*trc|") ;
while (<F>) {
 $p=1 if ((/tabn/) && (/\{$options{o}/)) ;
 $p=0 if /SQLID/;
 if (/tabn/) {
  ($day,$tm,$x3,$x4,$x5,$x6,$x7,$x8,$x9,$x10,$x11,$x12,$obj,$tbs,$x15)=split(' ',$_);
  print "Object: $obj $tbs $x15\n" if $p;
 }
 if (/rgnIdx/) {
  ($day,$tm,$x3,$x4,$x5,$x6,$x7,$x8,$x9,$x10,$x11,$x12,$rgnIdx,$x14,$x15,$x16,$x17,$x18,$x19)=split(' ',$_);
  print "\t$day $tm: Region Idx => $rgnIdx\n" if $p;
 }
 if (/Col id/) {
   print "\t\t$_" if $p;
 }
}
close(F);
